// Copyright Epic Games, Inc. All Rights Reserved.
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "uewav.h"

#if defined(__x86_64__) || defined(_M_X64)
#define UEW__X64_TARGET
#elif defined(__i386) || defined(_M_IX86)
#define UEW__X86_TARGET
#endif

#if defined(__GNUC__) && defined(UEW__X86_TARGET) && !defined(__SSE2__) && !defined(UEW_NO_SIMD)
// gcc doesn't support sse2 intrinsics unless you compile with -msse2,
// which in turn means it gets to use SSE2 everywhere. This is unfortunate,
// but previous attempts to provide the SSE2 functions with runtime
// detection caused numerous issues. The way architecture extensions are
// exposed in GCC/Clang is, sadly, not really suited for one-file libs.
// New behavior: if compiled with -msse2, we use SSE2 without any
// detection; if not, we don't use it at all.
#define UEW_NO_SIMD
#endif

#if !defined(UEW_NO_SIMD) && (defined(UEW__X86_TARGET) || defined(UEW__X64_TARGET))
#define UEW_SSE2
#include <emmintrin.h>
#endif

#ifdef __ARM_NEON
#include <arm_neon.h>
#endif

static void combine_hi_lo(unsigned char *lo, unsigned char *hi, unsigned short *out, long long num)
{
  int i = 0;
#ifdef UEW_SSE2
  for(; i < num-15; i+=16) {
    __m128i a = _mm_loadu_si128((__m128i*)(lo+i));
    __m128i b = _mm_loadu_si128((__m128i*)(hi+i));
    __m128i c = _mm_unpacklo_epi8(a, b);
    __m128i d = _mm_unpackhi_epi8(a, b);
    _mm_storeu_si128((__m128i*)(out+i), c);
    _mm_storeu_si128((__m128i*)(out+i+8), d);
  }
#endif
#ifdef __ARM_NEON
  for(; i < num-15; i += 16) {
    uint8x16_t a = vld1q_u8(lo+i);
    uint8x16_t b = vld1q_u8(hi+i);
    uint8x16x2_t c = vzipq_u8(a, b);
    vst1q_u8_x2((uint8_t*)(out+i), c);
  }
#endif
  for(; i < num; ++i) {
    out[i] = lo[i] | (hi[i] << 8);
  }
}

void uewav_encode16(short *samples, short *scratch_buffer, long long num_samples, long long num_channels) {
    long long i = 0;
    for(; i < num_channels && i < num_samples; ++i) {
        scratch_buffer[i] = samples[i];
    }
#ifdef UEW_SSE2
    for(; i < num_samples-7; i+=8) {
        // scratch_buffer[i] = (samples[i] - samples[i - num_channels]) + 0x80;
        __m128i a = _mm_loadu_si128((__m128i*)(samples+i));
        __m128i b = _mm_loadu_si128((__m128i*)(samples+i-num_channels));
        __m128i d = _mm_sub_epi16(a, b);
        __m128i e = _mm_add_epi16(d, _mm_set1_epi16(0x80));
        _mm_storeu_si128((__m128i*)(scratch_buffer+i), e);
    }
#endif
#if 0 //def __ARM_NEON needs testing...
#endif
	for (; i < num_samples; ++i) {
		scratch_buffer[i] = (samples[i] - samples[i - num_channels]) + 0x80;
	}
	unsigned char* lo = (unsigned char*)samples;
	unsigned char* hi = lo + num_samples;
    i = 0;
#ifdef UEW_SSE2
    for(; i < num_samples-15; i+=16) {
        // lo[i] = scratch_buffer[i] & 0xFF;
        // hi[i] = (scratch_buffer[i] >> 8) & 0xFF;
        __m128i a = _mm_loadu_si128((__m128i*)(scratch_buffer+i));
        __m128i a2 = _mm_loadu_si128((__m128i*)(scratch_buffer+i+8));
        __m128i b = _mm_and_si128(a, _mm_set1_epi16(0xFF));
        __m128i b2 = _mm_and_si128(a2, _mm_set1_epi16(0xFF));
        __m128i c = _mm_srli_epi16(a, 8);
        __m128i c2 = _mm_srli_epi16(a2, 8);
        _mm_storeu_si128((__m128i*)(lo+i), _mm_packus_epi16(b, b2));
        _mm_storeu_si128((__m128i*)(hi+i), _mm_packus_epi16(c, c2));
    }
#endif
#if 0 // def __ARM_NEON needs testing
#endif
	for (; i < num_samples; ++i) {
		lo[i] = (unsigned char)(scratch_buffer[i] & 0xFF);
		hi[i] = (unsigned char)((scratch_buffer[i] >> 8) & 0xFF);
	}
}

void uewav_decode16(short *samples, short *scratch_buffer, long long num_samples, long long num_channels) {
    unsigned char* lo = (unsigned char*)samples;
    unsigned char* hi = lo + num_samples;
    combine_hi_lo(lo, hi, (unsigned short*)scratch_buffer, num_samples);
    long long i = 0;
    for (; i < num_channels && i < num_samples; ++i) {
        samples[i] = scratch_buffer[i];
    }
    i = num_channels;
#ifdef UEW_SSE2
    if(num_channels == 1) {
        __m128i total = _mm_set1_epi16(samples[0]);
        for(; i < num_samples-7; i+=8) {
            __m128i b = _mm_sub_epi16( _mm_loadu_si128((__m128i*)(scratch_buffer+i)), _mm_set1_epi16(0x80));
            b = _mm_add_epi16(b, _mm_slli_si128(b, 2));
            b = _mm_add_epi16(b, _mm_slli_si128(b, 4)); 
            b = _mm_add_epi16(b, _mm_slli_si128(b, 8)); 

            __m128i d = _mm_add_epi16(total, b);
            _mm_storeu_si128((__m128i*)(samples+i), d);

            total = _mm_shuffle_epi32(_mm_unpackhi_epi16(d, d), _MM_SHUFFLE(3,3,3,3));
        };
    } else if(num_channels == 2) {
        __m128i total = _mm_set1_epi32(*(int*)samples);
        for(; i < num_samples-7; i+=8) {
            __m128i b = _mm_sub_epi16( _mm_loadu_si128((__m128i*)(scratch_buffer+i)), _mm_set1_epi16(0x80));
            b = _mm_add_epi16(b, _mm_slli_si128(b, 4));
            b = _mm_add_epi16(b, _mm_slli_si128(b, 8));

            __m128i d = _mm_add_epi16(total, b);
            _mm_storeu_si128((__m128i*)(samples+i), d);

            total = _mm_shuffle_epi32(d, _MM_SHUFFLE(3, 3, 3, 3));
        }
    } else if(num_channels == 8) {
        __m128i total = _mm_loadu_si128((__m128i*)(samples));
        for(; i < num_samples-7; i+=8) {
            __m128i b = _mm_sub_epi16( _mm_loadu_si128((__m128i*)(scratch_buffer+i)), _mm_set1_epi16(0x80));
            __m128i d = _mm_add_epi16(total, b);
            _mm_storeu_si128((__m128i*)(samples+i), d);
            total = d;
        }
    }
#endif
#ifdef __ARM_NEON
    // TODO
#endif
    for (; i < num_samples; ++i) {
        samples[i] = (scratch_buffer[i] - 0x80) + samples[i - num_channels];
    }
}
