// Copyright Epic Games, Inc. All Rights Reserved.
#include <stdlib.h>
#include <stdio.h>

#include "ext/oodle2.h"

//#define USE_TELEMETRY

#ifdef USE_TELEMETRY
#include "ext/rad_tm.h"
#else
#include "ext/rad_tm_stub.h"
#endif

#include "uejpeg.h"

static void *my_malloc(size_t size) { return malloc(size); }
static void my_free(void *ptr) { free(ptr); }
static void *my_realloc(void *ptr, size_t size) { return realloc(ptr, size); }

static uejpeg_alloc_t s_uejpeg_alloc = { my_malloc, my_free, my_realloc };

#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_STATIC
#define STBI_MALLOC s_uejpeg_alloc.alloc
#define STBI_REALLOC s_uejpeg_alloc.realloc
#define STBI_FREE s_uejpeg_alloc.free
#include "stb_image.h"

// x86/x64 detection
#if defined(__x86_64__) || defined(_M_X64)
#define UEJ__X64_TARGET
#elif defined(__i386) || defined(_M_IX86)
#define UEJ__X86_TARGET
#endif

#if defined(__GNUC__) && defined(UEJ__X86_TARGET) && !defined(__SSE2__) && !defined(UEJ_NO_SIMD)
#define UEJ_NO_SIMD
#endif

#if !defined(UEJ_NO_SIMD) && (defined(UEJ__X86_TARGET) || defined(UEJ__X64_TARGET))
#define UEJ_SSE2
#include <emmintrin.h>
#endif

static OodleLZ_Compressor compressor = OodleLZ_Compressor_Kraken;

static uejpeg_buffer_t my_compress(const void *uncomp, size_t uncomp_size) {
  tmEnter(0,0,__FUNCTION__);
  OodleLZ_CompressionLevel encode_level;
  if(uncomp_size > 4*1024*1024) {
    encode_level = OodleLZ_CompressionLevel_Normal;
  } else {
    encode_level = OodleLZ_CompressionLevel_Optimal5;
  }
  OodleLZ_CompressOptions options = * OodleLZ_CompressOptions_GetDefault(OodleLZ_Compressor_Kraken, encode_level);
  options.spaceSpeedTradeoffBytes = 16; // favor size over decode speed
  options.makeLongRangeMatcher = 0;
  void *compbuf = s_uejpeg_alloc.alloc(OodleLZ_GetCompressedBufferSizeNeeded(compressor, uncomp_size));
  OO_SINTa complen = OodleLZ_Compress(compressor, uncomp, uncomp_size, compbuf, encode_level, &options, 0, 0, 0, 0);
  uejpeg_buffer_t ret;
  ret.data = compbuf;
  ret.size = complen;
  tmLeave(0);
  return ret;
}

static int my_decompress(const void *data, size_t size, void *out_data, size_t out_size) {
  tmEnter(0,0,__FUNCTION__);
  int ret = (int)OodleLZ_Decompress(data, size, out_data, out_size, OodleLZ_FuzzSafe_Yes,OodleLZ_CheckCRC_No,OodleLZ_Verbosity_None,0,0,0,0,0,0,OodleLZ_Decode_Unthreaded);
  tmLeave(0);
  return ret;
}

static uejpeg_compression_t s_uejpeg_compression = {my_compress, my_decompress};

#define UEJPEG_IMAGE_VERSION (4)

static const int s_uejpeg_unzigzag[] = {
	 0,  1,  8, 16,  9,  2,  3, 10,
	17, 24, 32, 25, 18, 11,  4,  5,
	12, 19, 26, 33, 40, 48, 41, 34,
	27, 20, 13,  6,  7, 14, 21, 28,
	35, 42, 49, 56, 57, 50, 43, 36,
	29, 22, 15, 23, 30, 37, 44, 51,
	58, 59, 52, 45, 38, 31, 39, 46,
	53, 60, 61, 54, 47, 55, 62, 63
};

static const int s_uejpeg_zigzag[] = {
	 0,  1,  5,  6, 14, 15, 27, 28,
	 2,  4,  7, 13, 16, 26, 29, 42,
	 3,  8, 12, 17, 25, 30, 41, 43,
	 9, 11, 18, 24, 31, 40, 44, 53,
	10, 19, 23, 32, 39, 45, 52, 54,
	20, 22, 33, 38, 46, 51, 55, 60,
	21, 34, 37, 47, 50, 56, 59, 61,
	35, 36, 48, 49, 57, 58, 62, 63
};


static void io_putc(const uejpeg_io_callbacks_t *io, void *user, unsigned char c) {
  io->write(user, &c, 1);
}

static size_t uejpeg_write_buffer(void *user, const void *data, size_t size) {
    uejpeg_io_buffer_t *buf = (uejpeg_io_buffer_t*)user;
    size_t newsize = buf->size + size;
    void *newbase = s_uejpeg_alloc.realloc(buf->base, newsize);
    // Out of memory!
    if(!newbase) {
        s_uejpeg_alloc.free(buf->base);
        buf->size = 0;
        return 0;
    }
    ptrdiff_t at = (uintptr_t)buf->ptr - (uintptr_t)buf->base;
    buf->base = (char*)newbase;
    buf->ptr = (char*)(buf->base) + at;
    memcpy((char*)buf->base + buf->size, data, size);
    buf->size += size;
    return size;
}

static size_t uejpeg_read_buffer(void *user, void *data, size_t size) {
    uejpeg_io_buffer_t *buf = (uejpeg_io_buffer_t*)user;
    ptrdiff_t at = (uintptr_t)buf->ptr - (uintptr_t)buf->base;
    ptrdiff_t end = buf->size;
    size_t to_read = (end - at) < (ptrdiff_t)size ? (end - at) : size;
    size_t to_zero =  size - to_read;
    memcpy(data, buf->ptr, to_read);
    memset((char*)data + to_read, 0, to_zero);
    buf->ptr += to_read;
    return to_read;
}

static int uejpeg_eof_buffer(void *user) {
    uejpeg_io_buffer_t *buf = (uejpeg_io_buffer_t*)user;
    if(buf->ptr >= (char*)buf->base + buf->size) {
        return 1;
    }
    return 0;
}

const uejpeg_io_callbacks_t s_uejpeg_buffer_fns = {
  uejpeg_write_buffer, 
  uejpeg_read_buffer,
  uejpeg_eof_buffer,
};

typedef struct uejpeg_jpeg_info_t {
  int width, height; // comp is always 3 (RGB) - its a JPEG...
  // Quantization tables
  unsigned short dequant[4][64];
  // DCT coefficients
  short *coefs[4];
  int coefs_w[4];
  int coefs_h[4]; // number of 8x8 coefficient blocks
  char app14_color_transform; // valid values are 0(CMYK),1(YCCK),2(YCbCrA)
  char jfif;
  char comp_id[4];
} uejpeg_jpeg_info_t;

typedef struct chunk_t {
  unsigned length;
  unsigned type;
} chunk_t;

static unsigned char uejpeg__compute_y(int r, int g, int b) {
   return (unsigned char) (((r*77) + (g*150) +  (29*b)) >> 8);
}

// fast 0..255 * 0..255 => 0..255 rounded multiplication
static unsigned char uejpeg__blinn_8x8(unsigned char x, unsigned char y)
{
   unsigned int t = x*y + 128;
   return (unsigned char) ((t + (t >>8)) >> 8);
}

static void combine_hi_lo(unsigned char *foo_a, unsigned char *foo_b, unsigned short *out, int num)
{
  tmEnter(0,0,"hi/lo");
  int i = 0;
#ifdef UEJ_SSE2
  for(; i < num-15; i+=16) {
    __m128i a = _mm_loadu_si128((__m128i*)(foo_a+i));
    __m128i b = _mm_loadu_si128((__m128i*)(foo_b+i));
    __m128i c = _mm_unpacklo_epi8(a, b);
    __m128i d = _mm_unpackhi_epi8(a, b);
    _mm_storeu_si128((__m128i*)(out+i), c);
    _mm_storeu_si128((__m128i*)(out+i+8), d);
  }
#endif
#ifdef UEJ_NEON
  for(; i < num-15; i += 16) {
    uint8x16_t a = vld1q_u8(foo_a+i);
    uint8x16_t b = vld1q_u8(foo_b+i);
    uint8x16x2_t c = vzipq_u8(a, b);
    vst1q_u8_x2((uint8_t*)(out+i), c);
  }
#endif
  for(; i < num; ++i) {
    out[i] = foo_a[i] | (foo_b[i] << 8);
  }
  tmLeave(0);
}

static int uejpeg_read_jpeg_info(stbi__context *s, uejpeg_jpeg_info_t *info) {
  tmEnter(0,0,__FUNCTION__);
  memset(info, 0, sizeof(*info));

  stbi__jpeg* j = (stbi__jpeg*) stbi__malloc(sizeof(stbi__jpeg));
  j->s = s;
  stbi__setup_jpeg(j);
  if (!stbi__decode_jpeg_image(j)) { 
    stbi__cleanup_jpeg(j); 
    tmLeave(0);
    return 0; 
  }

  info->width = j->s->img_x;
  info->height = j->s->img_y;
  for(int i = 0; i < j->s->img_n; ++i) {
    info->coefs[i] = (short*)s_uejpeg_alloc.alloc(j->img_comp[i].coeff_w*j->img_comp[i].coeff_h*64*sizeof(short));
    memcpy(info->coefs[i], j->img_comp[i].coeff, j->img_comp[i].coeff_w*j->img_comp[i].coeff_h*64*sizeof(short));
    info->coefs_w[i] = j->img_comp[i].coeff_w;
    info->coefs_h[i] = j->img_comp[i].coeff_h;
    memcpy(info->dequant[i], j->dequant[j->img_comp[i].tq], sizeof(info->dequant[i]));
    for(int k = 0; k < 64; ++k) {
      if(info->dequant[i][k] <= 0) {
        stbi__cleanup_jpeg(j);
        STBI_FREE(j);
        tmLeave(0);
        return 0;
      }
    }
    info->comp_id[i] = (char)j->img_comp[i].id;
  }
  info->app14_color_transform = (char)j->app14_color_transform;
  info->jfif = (char)j->jfif;

  stbi__cleanup_jpeg(j);
  STBI_FREE(j);
  tmLeave(0);
  return 1;
}

// 1 split for every N blocks high
static int calc_num_splits(int height) {
  int num_splits = (height + 255) / 256;
  num_splits = num_splits > UEJPEG_MAX_SPLITS ? UEJPEG_MAX_SPLITS : num_splits;
  return num_splits;
}

static uejpeg_internal_splits_t make_splits(int num_splits, uejpeg_lossy_hdr_t *lhdr) {
  uejpeg_internal_splits_t s = {0};
  int min_h = INT_MAX;
  for(int i = 0; i < 4; ++i) {
    if(lhdr->coef_dims[i][1] && lhdr->coef_dims[i][1] < min_h) {
      min_h = lhdr->coef_dims[i][1];
    }
  }
  int split_height_min = (min_h + num_splits-1)/num_splits;
  s.total_split_blocks = 0;
  for(int i = 0; i < 4; ++i) {
    s.split_height[i] = (lhdr->coef_dims[i][1] / min_h) * split_height_min;
    s.split_blocks[i] = lhdr->coef_dims[i][0] * s.split_height[i];
    s.total_split_blocks += s.split_blocks[i];
  }
  for(int i = 0; i < num_splits; ++i) {
    s.splits[i].xcoefs = (short*)s_uejpeg_alloc.alloc(s.total_split_blocks * 64 * sizeof(short));
    s.splits[i].split_xcoefs = (char*)s_uejpeg_alloc.alloc(s.total_split_blocks * 64 * sizeof(short));
    if(!s.splits[i].xcoefs) s.error = UEJPEG_ERR_OUT_OF_MEMORY;
    if(!s.splits[i].split_xcoefs) s.error = UEJPEG_ERR_OUT_OF_MEMORY;
    s.splits[i].num_blocks = 0;
    for(int j = 0; j < 4; ++j) {
      s.splits[i].y_start[j] = s.split_height[j] * i;
      s.splits[i].y_end[j] = s.splits[i].y_start[j] + s.split_height[j];
      if(s.splits[i].y_start[j] > lhdr->coef_dims[j][1]) {
        s.splits[i].y_start[j] = lhdr->coef_dims[j][1];
      }
      if(s.splits[i].y_end[j] > lhdr->coef_dims[j][1]) {
        s.splits[i].y_end[j] = lhdr->coef_dims[j][1];
      }
      s.splits[i].width[j] = lhdr->coef_dims[j][0];
      s.splits[i].height[j] = s.splits[i].y_end[j] - s.splits[i].y_start[j];
      s.splits[i].num_blocks += s.splits[i].width[j] * s.splits[i].height[j];
    }
    s.splits[i].coefs_size = s.splits[i].num_blocks * 64;
  }
  return s;
}

static void free_splits(uejpeg_internal_splits_t *s) {
  for(int i = 0; i < UEJPEG_MAX_SPLITS; ++i) {
    if(s->splits[i].xcoefs) s_uejpeg_alloc.free(s->splits[i].xcoefs);
    if(s->splits[i].split_xcoefs) s_uejpeg_alloc.free(s->splits[i].split_xcoefs);
    if(s->splits[i].oodle_buf) s_uejpeg_alloc.free(s->splits[i].oodle_buf);
  }
}

static uejpeg_encode_context_t uejpeg_encode_jpeg_threaded_start(const uejpeg_io_callbacks_t *io, void *io_user, const uejpeg_jpeg_info_t *jpg_info, int flags) {
  tmEnter(0,0,__FUNCTION__);

  uejpeg_encode_context_t ctx = {0};
  ctx.io = io;
  ctx.io_user = io_user;
  ctx.flags = flags;
  ctx.width = jpg_info->width;
  ctx.height = jpg_info->height;

  for(int i = 0; i < 4; ++i) {
    if(jpg_info->coefs[i]) {
      ctx.lhdr.coef_dims[i][0] = (unsigned short)jpg_info->coefs_w[i];
      ctx.lhdr.coef_dims[i][1] = (unsigned short)jpg_info->coefs_h[i];
      ctx.lhdr.comp_id[i] = jpg_info->comp_id[i];
    }
  }
  ctx.lhdr.app14_color_transform = jpg_info->app14_color_transform;
  ctx.lhdr.jfif = jpg_info->jfif;
  memcpy(ctx.lhdr.dequant, jpg_info->dequant, sizeof(ctx.lhdr.dequant));

  ctx.comp = 0;
  for(int i = 0; i < 4; ++i) {
    if(jpg_info->coefs[i]) {
      ++ctx.comp;
      ctx.lhdr.coef_dims[i][0] = (unsigned short)jpg_info->coefs_w[i]; 
      ctx.lhdr.coef_dims[i][1] = (unsigned short)jpg_info->coefs_h[i]; 
    }
  }
  
  ctx.num_splits = calc_num_splits(ctx.height);
  ctx.jobs_to_run = ctx.num_splits;

  ctx.s = make_splits(ctx.num_splits, &ctx.lhdr);

  for(int s = 0; s < ctx.num_splits; ++s) {
    short *D = ctx.s.splits[s].xcoefs;
    for(int c = 0; c < 4; ++c) {
      if(jpg_info->coefs[c]) {
        int y_start = ctx.s.splits[s].y_start[c];
        int w = ctx.s.splits[s].width[c];
        int h = ctx.s.splits[s].height[c];
        int num_blocks = w * h;
        short *C = jpg_info->coefs[c] + y_start*w*64;
        for(int y = 0; y < h; ++y) {
          for(int x = 0; x < w; ++x) {
            for(int k = 0; k < 64; ++k) {
              int coef = C[s_uejpeg_zigzag[k]] / ctx.lhdr.dequant[c][s_uejpeg_zigzag[k]];
              D[k*num_blocks + y*w+x] = (short)(coef + 0x80); // requantize... stb gives it to us unquantized coefs
            }
            C += 64;
          }
        }
        D += num_blocks * 64;
      }
    }
  }

  tmLeave(0);
  return ctx;
}

int uejpeg_encode_jpeg_thread_run(uejpeg_encode_context_t *ctx, int job_idx) {
  // If we are in error state, do nothing...
  if(ctx->error || job_idx < 0 || job_idx >= ctx->jobs_to_run) {
    return ctx->error;
  }
  tmEnter(0,0,__FUNCTION__);
  // split bytes of int16 into their own sections
  {
    short *dct_data = ctx->s.splits[job_idx].xcoefs;
    char *dct_a = ctx->s.splits[job_idx].split_xcoefs;
    char *dct_b = ctx->s.splits[job_idx].split_xcoefs + ctx->s.splits[job_idx].coefs_size;
    for(int i = 0; i < ctx->s.splits[job_idx].coefs_size; ++i) {
      dct_a[i] = dct_data[i] & 0xFF;
      dct_b[i] = dct_data[i] >> 8;
    }
  }
  if(ctx->flags & UEJPEG_FLAG_NO_COMPRESSION) {
    ctx->s.splits[job_idx].oodle_buf = (unsigned char *)s_uejpeg_alloc.alloc(ctx->s.splits[job_idx].coefs_size*2);
    ctx->s.splits[job_idx].oodle_size = (int)ctx->s.splits[job_idx].coefs_size*2;
    memcpy(ctx->s.splits[job_idx].oodle_buf, ctx->s.splits[job_idx].split_xcoefs, ctx->s.splits[job_idx].coefs_size*2);
  } else {
    uejpeg_buffer_t oodle = s_uejpeg_compression.compress(ctx->s.splits[job_idx].split_xcoefs, ctx->s.splits[job_idx].coefs_size*2);
    ctx->s.splits[job_idx].oodle_buf = (unsigned char *)oodle.data;
    ctx->s.splits[job_idx].oodle_size = (int)oodle.size;
  }
  tmLeave(0);
  return 0;
}

int uejpeg_encode_jpeg_threaded_finish(uejpeg_encode_context_t *ctx) {
  // If we are in error state, do nothing...
  if(ctx->error) {
    return ctx->error;
  }
  tmEnter(0,0,__FUNCTION__);

  // Write uejpeg file header
  ctx->io->write(ctx->io_user, "OOJPEG", 6);

  uejpeg_ihdr_t uejpeg_ihdr = {0};
  uejpeg_ihdr.version = UEJPEG_IMAGE_VERSION;
  uejpeg_ihdr.width = ctx->width;
  uejpeg_ihdr.height = ctx->height;
  uejpeg_ihdr.bit_depth = 8;
  uejpeg_ihdr.comp = (unsigned char)ctx->comp; // RGB
  if(ctx->flags & UEJPEG_FLAG_NO_COMPRESSION) {
    uejpeg_ihdr.method = 0; // No Compression
  } else {
    uejpeg_ihdr.method = 0x0D; // Oodle LZ
  }
  uejpeg_ihdr.num_splits = (unsigned char)ctx->num_splits;

  // Write IHDR
  chunk_t ihdr_chunk = {sizeof uejpeg_ihdr, 'RDHI'};
  ctx->io->write(ctx->io_user, &ihdr_chunk, 8);
  ctx->io->write(ctx->io_user, &uejpeg_ihdr, sizeof uejpeg_ihdr);

  // Write LHDR
  chunk_t lhdr_chunk = {sizeof uejpeg_ihdr, 'RDHL'};
  ctx->io->write(ctx->io_user, &lhdr_chunk, 8);
  ctx->io->write(ctx->io_user, &ctx->lhdr, sizeof ctx->lhdr);

  // Write SPLT chunks
  for(int i = 0; i < ctx->num_splits; ++i) {
    ctx->io->write(ctx->io_user, &ctx->s.splits[i].oodle_size, 4);
    ctx->io->write(ctx->io_user, "SPLT", 4);
    ctx->io->write(ctx->io_user, ctx->s.splits[i].oodle_buf, ctx->s.splits[i].oodle_size);
  }

//fail:
  free_splits(&ctx->s);
  tmLeave(0);
  return ctx->error;
}

static void jo_writeBits(const uejpeg_io_callbacks_t *io, void *io_user, int *bitBuf, int *bitCnt, const unsigned short *bs) {
	*bitCnt += bs[1];
	*bitBuf |= bs[0] << (24 - *bitCnt);
	while(*bitCnt >= 8) {
		unsigned char c = (*bitBuf >> 16) & 255;
		io_putc(io, io_user, c);
		if(c == 255) {
			io_putc(io, io_user, 0);
		}
		*bitBuf <<= 8;
		*bitCnt -= 8;
	}
}

static void jo_calcBits(int val, unsigned short bits[2]) {
	int tmp1 = val < 0 ? -val : val;
	val = val < 0 ? val-1 : val;
	bits[1] = 1;
	while(tmp1 >>= 1) {
		++bits[1];
	}
	bits[0] = val & ((1<<bits[1])-1);
}

static int jo_processDU(const uejpeg_io_callbacks_t *io, void *io_user, int *bitBuf, int *bitCnt, int *DU, int DC, const unsigned short HTDC[256][2], const unsigned short HTAC[256][2]) {
	unsigned short EOB[2];
	unsigned short M16zeroes[2];

  EOB[0] = HTAC[0][0];
  EOB[1] = HTAC[0][1];
  M16zeroes[0] = HTAC[0xF0][0];
  M16zeroes[1] = HTAC[0xF0][1];

	// Encode DC
	int diff = DU[0] - DC; 
	if (diff == 0) {
		jo_writeBits(io, io_user, bitBuf, bitCnt, HTDC[0]);
	} else {
		unsigned short bits[2];
		jo_calcBits(diff, bits);
		jo_writeBits(io, io_user, bitBuf, bitCnt, HTDC[bits[1]]);
		jo_writeBits(io, io_user, bitBuf, bitCnt, bits);
	}
	// Encode ACs
	int end0pos = 63;
	for(; (end0pos>0)&&(DU[end0pos]==0); --end0pos) {
	}
	// end0pos = first element in reverse order !=0
	if(end0pos == 0) {
		jo_writeBits(io, io_user, bitBuf, bitCnt, EOB);
		return DU[0];
	}
	for(int i = 1; i <= end0pos; ++i) {
		int startpos = i;
		for (; DU[i]==0 && i<=end0pos; ++i) {
		}
		int nrzeroes = i-startpos;
		if ( nrzeroes >= 16 ) {
			int lng = nrzeroes>>4;
			for (int nrmarker=1; nrmarker <= lng; ++nrmarker)
				jo_writeBits(io, io_user, bitBuf, bitCnt, M16zeroes);
			nrzeroes &= 15;
		}
		unsigned short bits[2];
		jo_calcBits(DU[i], bits);
		jo_writeBits(io, io_user, bitBuf, bitCnt, HTAC[(nrzeroes<<4)+bits[1]]);
		jo_writeBits(io, io_user, bitBuf, bitCnt, bits);
	}
	if(end0pos != 63) {
		jo_writeBits(io, io_user, bitBuf, bitCnt, EOB);
	}
	return DU[0];
}

int uejpeg_decode_to_jpeg(const uejpeg_io_callbacks_t *in_io, void *in_io_user, const uejpeg_io_callbacks_t *out_io, void *out_io_user, int flags) {
  // Constants that don't pollute global namespace
  static const unsigned char std_dc_luminance_nrcodes[] = {0,0,1,5,1,1,1,1,1,1,0,0,0,0,0,0,0};
  static const unsigned char std_dc_luminance_values[] = {0,1,2,3,4,5,6,7,8,9,10,11};
  static const unsigned char std_ac_luminance_nrcodes[] = {0,0,2,1,3,3,2,4,3,5,5,4,4,0,0,1,0x7d};
  static const unsigned char std_ac_luminance_values[] = {
    0x01,0x02,0x03,0x00,0x04,0x11,0x05,0x12,0x21,0x31,0x41,0x06,0x13,0x51,0x61,0x07,0x22,0x71,0x14,0x32,0x81,0x91,0xa1,0x08,
    0x23,0x42,0xb1,0xc1,0x15,0x52,0xd1,0xf0,0x24,0x33,0x62,0x72,0x82,0x09,0x0a,0x16,0x17,0x18,0x19,0x1a,0x25,0x26,0x27,0x28,
    0x29,0x2a,0x34,0x35,0x36,0x37,0x38,0x39,0x3a,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4a,0x53,0x54,0x55,0x56,0x57,0x58,0x59,
    0x5a,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6a,0x73,0x74,0x75,0x76,0x77,0x78,0x79,0x7a,0x83,0x84,0x85,0x86,0x87,0x88,0x89,
    0x8a,0x92,0x93,0x94,0x95,0x96,0x97,0x98,0x99,0x9a,0xa2,0xa3,0xa4,0xa5,0xa6,0xa7,0xa8,0xa9,0xaa,0xb2,0xb3,0xb4,0xb5,0xb6,
    0xb7,0xb8,0xb9,0xba,0xc2,0xc3,0xc4,0xc5,0xc6,0xc7,0xc8,0xc9,0xca,0xd2,0xd3,0xd4,0xd5,0xd6,0xd7,0xd8,0xd9,0xda,0xe1,0xe2,
    0xe3,0xe4,0xe5,0xe6,0xe7,0xe8,0xe9,0xea,0xf1,0xf2,0xf3,0xf4,0xf5,0xf6,0xf7,0xf8,0xf9,0xfa
  };
  static const unsigned char std_dc_chrominance_nrcodes[] = {0,0,3,1,1,1,1,1,1,1,1,1,0,0,0,0,0};
  static const unsigned char std_dc_chrominance_values[] = {0,1,2,3,4,5,6,7,8,9,10,11};
  static const unsigned char std_ac_chrominance_nrcodes[] = {0,0,2,1,2,4,4,3,4,7,5,4,4,0,1,2,0x77};
  static const unsigned char std_ac_chrominance_values[] = {
    0x00,0x01,0x02,0x03,0x11,0x04,0x05,0x21,0x31,0x06,0x12,0x41,0x51,0x07,0x61,0x71,0x13,0x22,0x32,0x81,0x08,0x14,0x42,0x91,
    0xa1,0xb1,0xc1,0x09,0x23,0x33,0x52,0xf0,0x15,0x62,0x72,0xd1,0x0a,0x16,0x24,0x34,0xe1,0x25,0xf1,0x17,0x18,0x19,0x1a,0x26,
    0x27,0x28,0x29,0x2a,0x35,0x36,0x37,0x38,0x39,0x3a,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4a,0x53,0x54,0x55,0x56,0x57,0x58,
    0x59,0x5a,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6a,0x73,0x74,0x75,0x76,0x77,0x78,0x79,0x7a,0x82,0x83,0x84,0x85,0x86,0x87,
    0x88,0x89,0x8a,0x92,0x93,0x94,0x95,0x96,0x97,0x98,0x99,0x9a,0xa2,0xa3,0xa4,0xa5,0xa6,0xa7,0xa8,0xa9,0xaa,0xb2,0xb3,0xb4,
    0xb5,0xb6,0xb7,0xb8,0xb9,0xba,0xc2,0xc3,0xc4,0xc5,0xc6,0xc7,0xc8,0xc9,0xca,0xd2,0xd3,0xd4,0xd5,0xd6,0xd7,0xd8,0xd9,0xda,
    0xe2,0xe3,0xe4,0xe5,0xe6,0xe7,0xe8,0xe9,0xea,0xf2,0xf3,0xf4,0xf5,0xf6,0xf7,0xf8,0xf9,0xfa
  };
  // Huffman tables
  static const unsigned short YDC_HT[256][2] = { {0,2},{2,3},{3,3},{4,3},{5,3},{6,3},{14,4},{30,5},{62,6},{126,7},{254,8},{510,9}};
  static const unsigned short UVDC_HT[256][2] = { {0,2},{1,2},{2,2},{6,3},{14,4},{30,5},{62,6},{126,7},{254,8},{510,9},{1022,10},{2046,11}};
  static const unsigned short YAC_HT[256][2] = { 
    {10,4},{0,2},{1,2},{4,3},{11,4},{26,5},{120,7},{248,8},{1014,10},{65410,16},{65411,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {12,4},{27,5},{121,7},{502,9},{2038,11},{65412,16},{65413,16},{65414,16},{65415,16},{65416,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {28,5},{249,8},{1015,10},{4084,12},{65417,16},{65418,16},{65419,16},{65420,16},{65421,16},{65422,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {58,6},{503,9},{4085,12},{65423,16},{65424,16},{65425,16},{65426,16},{65427,16},{65428,16},{65429,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {59,6},{1016,10},{65430,16},{65431,16},{65432,16},{65433,16},{65434,16},{65435,16},{65436,16},{65437,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {122,7},{2039,11},{65438,16},{65439,16},{65440,16},{65441,16},{65442,16},{65443,16},{65444,16},{65445,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {123,7},{4086,12},{65446,16},{65447,16},{65448,16},{65449,16},{65450,16},{65451,16},{65452,16},{65453,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {250,8},{4087,12},{65454,16},{65455,16},{65456,16},{65457,16},{65458,16},{65459,16},{65460,16},{65461,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {504,9},{32704,15},{65462,16},{65463,16},{65464,16},{65465,16},{65466,16},{65467,16},{65468,16},{65469,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {505,9},{65470,16},{65471,16},{65472,16},{65473,16},{65474,16},{65475,16},{65476,16},{65477,16},{65478,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {506,9},{65479,16},{65480,16},{65481,16},{65482,16},{65483,16},{65484,16},{65485,16},{65486,16},{65487,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {1017,10},{65488,16},{65489,16},{65490,16},{65491,16},{65492,16},{65493,16},{65494,16},{65495,16},{65496,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {1018,10},{65497,16},{65498,16},{65499,16},{65500,16},{65501,16},{65502,16},{65503,16},{65504,16},{65505,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {2040,11},{65506,16},{65507,16},{65508,16},{65509,16},{65510,16},{65511,16},{65512,16},{65513,16},{65514,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {65515,16},{65516,16},{65517,16},{65518,16},{65519,16},{65520,16},{65521,16},{65522,16},{65523,16},{65524,16},{0,0},{0,0},{0,0},{0,0},{0,0},
    {2041,11},{65525,16},{65526,16},{65527,16},{65528,16},{65529,16},{65530,16},{65531,16},{65532,16},{65533,16},{65534,16},{0,0},{0,0},{0,0},{0,0},{0,0}
  };
  static const unsigned short UVAC_HT[256][2] = { 
    {0,2},{1,2},{4,3},{10,4},{24,5},{25,5},{56,6},{120,7},{500,9},{1014,10},{4084,12},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {11,4},{57,6},{246,8},{501,9},{2038,11},{4085,12},{65416,16},{65417,16},{65418,16},{65419,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {26,5},{247,8},{1015,10},{4086,12},{32706,15},{65420,16},{65421,16},{65422,16},{65423,16},{65424,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {27,5},{248,8},{1016,10},{4087,12},{65425,16},{65426,16},{65427,16},{65428,16},{65429,16},{65430,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {58,6},{502,9},{65431,16},{65432,16},{65433,16},{65434,16},{65435,16},{65436,16},{65437,16},{65438,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {59,6},{1017,10},{65439,16},{65440,16},{65441,16},{65442,16},{65443,16},{65444,16},{65445,16},{65446,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {121,7},{2039,11},{65447,16},{65448,16},{65449,16},{65450,16},{65451,16},{65452,16},{65453,16},{65454,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {122,7},{2040,11},{65455,16},{65456,16},{65457,16},{65458,16},{65459,16},{65460,16},{65461,16},{65462,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {249,8},{65463,16},{65464,16},{65465,16},{65466,16},{65467,16},{65468,16},{65469,16},{65470,16},{65471,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {503,9},{65472,16},{65473,16},{65474,16},{65475,16},{65476,16},{65477,16},{65478,16},{65479,16},{65480,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {504,9},{65481,16},{65482,16},{65483,16},{65484,16},{65485,16},{65486,16},{65487,16},{65488,16},{65489,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {505,9},{65490,16},{65491,16},{65492,16},{65493,16},{65494,16},{65495,16},{65496,16},{65497,16},{65498,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {506,9},{65499,16},{65500,16},{65501,16},{65502,16},{65503,16},{65504,16},{65505,16},{65506,16},{65507,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {2041,11},{65508,16},{65509,16},{65510,16},{65511,16},{65512,16},{65513,16},{65514,16},{65515,16},{65516,16},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},
    {16352,14},{65517,16},{65518,16},{65519,16},{65520,16},{65521,16},{65522,16},{65523,16},{65524,16},{65525,16},{0,0},{0,0},{0,0},{0,0},{0,0},
    {1018,10},{32707,15},{65526,16},{65527,16},{65528,16},{65529,16},{65530,16},{65531,16},{65532,16},{65533,16},{65534,16},{0,0},{0,0},{0,0},{0,0},{0,0}
  };

  int err = UEJPEG_ERR_CORRUPT_UEJPEG_FILE;

  char magic[6];
  if(in_io->read(in_io_user, magic, 6) != 6) {
      return UEJPEG_ERR_NOT_UEJPEG_FILE;
  }
  if(memcmp(magic, "OOJPEG", 6)) {
      return UEJPEG_ERR_NOT_UEJPEG_FILE;
  }

  tmEnter(0,0,__FUNCTION__);

  uejpeg_ihdr_t ihdr = {0};
  uejpeg_lossy_hdr_t lhdr = {{{0}}};
  uejpeg_internal_splits_t spx = {0};
  int width = 0, height = 0, comp = 0, bit_depth = 0;
  int num_splits = 0;
  int DCY = 0, DCU = 0, DCV = 0;
  int bitBuf = 0, bitCnt = 0;
  chunk_t c;

  // IHDR chunk
  if (in_io->read(in_io_user, &c, 8) != 8) goto fail;
  if(c.type != 'RDHI') goto fail;
  if(in_io->read(in_io_user, &ihdr, sizeof(ihdr)) != sizeof(ihdr)) goto fail;
  if(ihdr.version != UEJPEG_IMAGE_VERSION) goto fail;
  width = ihdr.width; if(!width || width > (1<<24)) goto fail;
  height = ihdr.height; if(!height || height > (1<<24)) goto fail;
  comp = ihdr.comp; if(comp != 3) { err = UEJPEG_ERR_UNSUPPORTED_COLORSPACE; goto fail; }
  bit_depth = ihdr.bit_depth; if(bit_depth != 8) goto fail;
  num_splits = ihdr.num_splits; if(num_splits < 1 || num_splits > UEJPEG_MAX_SPLITS) goto fail;
  if(!stbi__mad3sizes_valid(width, height, comp, 0)) goto fail;
  if(width*height*comp == 0) goto fail;

  // LHDR chunk
  if(in_io->read(in_io_user, &c, 8) != 8) goto fail;
  if(c.type != 'RDHL') goto fail;
  if(in_io->read(in_io_user, &lhdr, sizeof(lhdr)) != sizeof(lhdr)) goto fail;

  int use_h2v1 = 0;
  int use_h2v2 = 0;
  int use_h1v2 = 0;

  // validate lhdr
  {
    if(lhdr.app14_color_transform != (char)-1 && lhdr.app14_color_transform != 0 && lhdr.app14_color_transform != 1 && lhdr.app14_color_transform != 2) goto fail;
    int h_max = 1, v_max = 1;
    for(int i=0; i < comp; ++i) {
      if (lhdr.coef_dims[i][0] > h_max) h_max = lhdr.coef_dims[i][0];
      if (lhdr.coef_dims[i][1] > v_max) v_max = lhdr.coef_dims[i][1];
    }
    for(int i = 0; i < comp; ++i) {
      int hs = h_max / lhdr.coef_dims[i][0];
      if(lhdr.coef_dims[i][0] * 8 > ((width+7)/8*8)+8) goto fail;// || lhdr.coef_dims[i][1] * 8 > ((height+7)/8*8)) goto fail;
      if(lhdr.coef_dims[i][0] * 8 < (width/8*8/hs)) goto fail;
      if(lhdr.coef_dims[i][0] * lhdr.coef_dims[i][1] == 0) goto fail;
    }
    for(int i = comp; i < 4; ++i) {
      if(lhdr.coef_dims[i][0] != 0 || lhdr.coef_dims[i][1] != 0) goto fail;
    }
    for(int i=0; i < comp; ++i) {
      int hs = h_max / lhdr.coef_dims[i][0];
      int vs = v_max / lhdr.coef_dims[i][1];
      if(h_max % lhdr.coef_dims[i][0]) goto fail;
      if(v_max % lhdr.coef_dims[i][1]) goto fail;
      if(hs != 1 && hs != 2) { err = UEJPEG_ERR_UNSUPPORTED; goto fail; }
      if(vs != 1 && vs != 2) { err = UEJPEG_ERR_UNSUPPORTED; goto fail; }
      if(hs == 2 && vs == 1) {
        use_h2v1 = 1;
      } else if(hs == 1 && vs == 2) {
        use_h1v2 = 1;
      } else if(hs == 2 && vs == 2) {
        use_h2v2 = 1;
      } else if(hs != vs) {
        err = UEJPEG_ERR_UNSUPPORTED; 
        goto fail;
      } 
    }
  }

  spx = make_splits(num_splits, &lhdr);

  // SPLT chunks
  for(int sp = 0; sp < num_splits; ++sp) {
    if(in_io->read(in_io_user, &c, 8) != 8) goto fail;
    if(c.type != 'TLPS') goto fail;
    spx.splits[sp].oodle_buf = (unsigned char*)s_uejpeg_alloc.alloc(c.length);
    if(!spx.splits[sp].oodle_buf) { err = UEJPEG_ERR_OUT_OF_MEMORY; goto fail; }
    if(spx.splits[sp].oodle_size != spx.splits[sp].coefs_size*2 && ihdr.method == 0) goto fail;
    if(in_io->read(in_io_user, spx.splits[sp].oodle_buf, c.length) != c.length) goto fail;

    // No compression?
    if(ihdr.method == 0) {
      memcpy(spx.splits[sp].split_xcoefs, spx.splits[sp].oodle_buf, c.length);
    } else {
      if(c.length && !s_uejpeg_compression.decompress(spx.splits[sp].oodle_buf, c.length, spx.splits[sp].split_xcoefs, spx.splits[sp].coefs_size*2)) goto fail;
    }

    // put hi/lo bytes back together into shorts
    combine_hi_lo((unsigned char*)spx.splits[sp].split_xcoefs, 
      (unsigned char*)spx.splits[sp].split_xcoefs + spx.splits[sp].coefs_size,
      (unsigned short*)spx.splits[sp].xcoefs,
      spx.splits[sp].coefs_size);
  }


  // Write Headers
  static const unsigned char head0[] = {0xFF, 0xD8, 0xFF, 0xE0, 0, 0x10, 'J', 'F', 'I', 'F', 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0xFF, 0xDB, 0x01, 0x04, 0x10};
  out_io->write(out_io_user, head0, sizeof(head0));
  for(int i = 0; i < 64; ++i) {
    io_putc(out_io, out_io_user, lhdr.dequant[0][s_uejpeg_unzigzag[i]]>>8);
    io_putc(out_io, out_io_user, lhdr.dequant[0][s_uejpeg_unzigzag[i]]&0xFF);
  }
  io_putc(out_io, out_io_user, 0x11);
  for(int i = 0; i < 64; ++i) {
    io_putc(out_io, out_io_user, lhdr.dequant[1][s_uejpeg_unzigzag[i]]>>8);
    io_putc(out_io, out_io_user, lhdr.dequant[1][s_uejpeg_unzigzag[i]]&0xFF);
  }
  unsigned char head1[] = {0xFF, 0xC0, 0, 0x11, 8, 0, 0, 0, 0, 3, 1, 0x11, 0, 2, 0x11, 1, 3, 0x11, 1, 0xFF, 0xC4, 0x01, 0xA2, 0};
  head1[5] = (unsigned char)(height >> 8);
  head1[6] = (unsigned char)(height & 0xFF);
  head1[7] = (unsigned char)(width >> 8);
  head1[8] = (unsigned char)(width & 0xFF);
  if(use_h2v1) head1[11] = 0x21;
  else if(use_h2v2) head1[11] = 0x22;
  else if(use_h1v2) head1[11] = 0x12;
  else head1[11] = 0x11;
  if(out_io->write(out_io_user, head1, sizeof(head1)) != sizeof(head1)) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  if(out_io->write(out_io_user, std_dc_luminance_nrcodes + 1, sizeof(std_dc_luminance_nrcodes) - 1) != sizeof(std_dc_luminance_nrcodes) - 1) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  if(out_io->write(out_io_user, std_dc_luminance_values, sizeof(std_dc_luminance_values)) != sizeof(std_dc_luminance_values)) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  io_putc(out_io, out_io_user, 0x10); // HTYACinfo
  if(out_io->write(out_io_user, std_ac_luminance_nrcodes + 1, sizeof(std_ac_luminance_nrcodes) - 1) != sizeof(std_ac_luminance_nrcodes) - 1) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  if(out_io->write(out_io_user, std_ac_luminance_values, sizeof(std_ac_luminance_values)) != sizeof(std_ac_luminance_values)) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  io_putc(out_io, out_io_user, 0x01); // HTUDCinfo
  if(out_io->write(out_io_user, std_dc_chrominance_nrcodes + 1, sizeof(std_dc_chrominance_nrcodes) - 1) != sizeof(std_dc_chrominance_nrcodes) - 1) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  if(out_io->write(out_io_user, std_dc_chrominance_values, sizeof(std_dc_chrominance_values)) != sizeof(std_dc_chrominance_values)) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  io_putc(out_io, out_io_user, 0x11); // HTUACinfo
  if(out_io->write(out_io_user, std_ac_chrominance_nrcodes + 1, sizeof(std_ac_chrominance_nrcodes) - 1) != sizeof(std_ac_chrominance_nrcodes) - 1) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  if(out_io->write(out_io_user, std_ac_chrominance_values, sizeof(std_ac_chrominance_values)) != sizeof(std_ac_chrominance_values)) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  static const unsigned char head2[] = {0xFF, 0xDA, 0, 0xC, 3, 1, 0, 2, 0x11, 3, 0x11, 0, 0x3F, 0};
  if(out_io->write(out_io_user, head2, sizeof(head2)) != sizeof(head2)) { err = UEJPEG_ERR_WRITE_FAILED; goto fail; }

  // now re-encode to normal JPEG
  tmEnter(0,0,"processDUs");
  if(!use_h2v2 && !use_h2v1 && !use_h1v2) {
    for(int sp = 0; sp < num_splits; ++sp) {
      int bw = spx.splits[sp].width[0];
      int bh = spx.splits[sp].height[0];
      int num_blocks = bw*bh;
      for(int y = 0; y < bh; ++y) {
        for(int x = 0; x < bw; ++x) {
          short *D = spx.splits[sp].xcoefs + y*bw+x;
          int C[4][64];
          for(int cc = 0; cc < comp; ++cc) {
            for(int e = 0; e < 64; ++e) {
              int d = s_uejpeg_unzigzag[e]*num_blocks;
              C[cc][s_uejpeg_zigzag[e]] = D[d] - 0x80;
            }
            D += num_blocks*64;
          }
          DCY = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[0], DCY, YDC_HT, YAC_HT);
          DCU = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[1], DCU, UVDC_HT, UVAC_HT);
          DCV = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[2], DCV, UVDC_HT, UVAC_HT);
        }
      }
    }
  } else if(use_h2v1) {
    for(int sp = 0; sp < num_splits; ++sp) {
      for(int y = 0; y < spx.splits[sp].height[0]; y+=1) {
        for(int x = 0; x < spx.splits[sp].width[0]; x+=2) {
          short *X = spx.splits[sp].xcoefs;
          int C[7][64];
          // Y
          {
            int bw = spx.splits[sp].width[0];
            int bh = spx.splits[sp].height[0];
            int num_blocks = bw*bh;
            for(int yy = y, ci = 0; yy < y+1; ++yy) {
              for(int xx = x; xx < x+2; ++xx, ++ci) {
                short *D = X + yy*bw+xx;
                for(int e = 0; e < 64; ++e) {
                  int d = s_uejpeg_unzigzag[e]*num_blocks;
                  C[ci][s_uejpeg_zigzag[e]] = D[d] - 0x80;
                }
              }
            }
            X += num_blocks*64;
          }
          // U,V
          for(int cc = 1; cc < comp; ++cc) {
            int bw = spx.splits[sp].width[cc];
            int bh = spx.splits[sp].height[cc];
            int num_blocks = bw*bh;
            short *D = X + (y)*bw+(x/2);
            for(int e = 0; e < 64; ++e) {
              int d = s_uejpeg_unzigzag[e]*num_blocks;
              C[cc+3][s_uejpeg_zigzag[e]] = D[d] - 0x80;
            }
            X += num_blocks*64;
          }
          DCY = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[0], DCY, YDC_HT, YAC_HT);
          DCY = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[1], DCY, YDC_HT, YAC_HT);
          DCU = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[4], DCU, UVDC_HT, UVAC_HT);
          DCV = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[5], DCV, UVDC_HT, UVAC_HT);
        }
      }
    }
  } else if(use_h1v2) {
    for(int sp = 0; sp < num_splits; ++sp) {
      for(int y = 0; y < spx.splits[sp].height[0]; y+=2) {
        for(int x = 0; x < spx.splits[sp].width[0]; x+=1) {
          short *X = spx.splits[sp].xcoefs;
          int C[7][64];
          // Y
          {
            int bw = spx.splits[sp].width[0];
            int bh = spx.splits[sp].height[0];
            int num_blocks = bw*bh;
            for(int yy = y, ci = 0; yy < y+2; ++yy) {
              for(int xx = x; xx < x+1; ++xx, ++ci) {
                short *D = X + yy*bw+xx;
                for(int e = 0; e < 64; ++e) {
                  int d = s_uejpeg_unzigzag[e]*num_blocks;
                  C[ci][s_uejpeg_zigzag[e]] = D[d] - 0x80;
                }
              }
            }
            X += num_blocks*64;
          }
          // U,V
          for(int cc = 1; cc < comp; ++cc) {
            int bw = spx.splits[sp].width[cc];
            int bh = spx.splits[sp].height[cc];
            int num_blocks = bw*bh;
            short *D = X + (y/2)*bw+(x);
            for(int e = 0; e < 64; ++e) {
              int d = s_uejpeg_unzigzag[e]*num_blocks;
              C[cc+3][s_uejpeg_zigzag[e]] = D[d] - 0x80;
            }
            X += num_blocks*64;
          }
          DCY = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[0], DCY, YDC_HT, YAC_HT);
          DCY = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[1], DCY, YDC_HT, YAC_HT);
          DCU = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[4], DCU, UVDC_HT, UVAC_HT);
          DCV = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[5], DCV, UVDC_HT, UVAC_HT);
        }
      }
    }
  } else {
    for(int sp = 0; sp < num_splits; ++sp) {
      for(int y = 0; y < spx.splits[sp].height[0]; y+=2) {
        for(int x = 0; x < spx.splits[sp].width[0]; x+=2) {
          short *X = spx.splits[sp].xcoefs;
          int C[7][64];
          // Y
          {
            int bw = spx.splits[sp].width[0];
            int bh = spx.splits[sp].height[0];
            int num_blocks = bw*bh;
            for(int yy = y, ci = 0; yy < y+2; ++yy) {
              for(int xx = x; xx < x+2; ++xx, ++ci) {
                short *D = X + yy*bw+xx;
                for(int e = 0; e < 64; ++e) {
                  int d = s_uejpeg_unzigzag[e]*num_blocks;
                  C[ci][s_uejpeg_zigzag[e]] = D[d] - 0x80;
                }
              }
            }
            X += num_blocks*64;
          }
          // U,V
          for(int cc = 1; cc < comp; ++cc) {
            int bw = spx.splits[sp].width[cc];
            int bh = spx.splits[sp].height[cc];
            int num_blocks = bw*bh;
            short *D = X + (y/2)*bw+(x/2);
            for(int e = 0; e < 64; ++e) {
              int d = s_uejpeg_unzigzag[e]*num_blocks;
              C[cc+3][s_uejpeg_zigzag[e]] = D[d] - 0x80;
            }
            X += num_blocks*64;
          }
          DCY = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[0], DCY, YDC_HT, YAC_HT);
          DCY = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[1], DCY, YDC_HT, YAC_HT);
          DCY = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[2], DCY, YDC_HT, YAC_HT);
          DCY = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[3], DCY, YDC_HT, YAC_HT);
          DCU = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[4], DCU, UVDC_HT, UVAC_HT);
          DCV = jo_processDU(out_io, out_io_user, &bitBuf, &bitCnt, C[5], DCV, UVDC_HT, UVAC_HT);
        }
      }
    }
  }
  tmLeave(0);

  // Do the bit alignment of the EOI marker
  static const unsigned short fillBits[] = {0x7F, 7};
  jo_writeBits(out_io, out_io_user, &bitBuf, &bitCnt, fillBits);
  io_putc(out_io, out_io_user, 0xFF);
  io_putc(out_io, out_io_user, 0xD9);

  free_splits(&spx);
  tmLeave(0);
  return 0;
fail:
  free_splits(&spx);
  tmLeave(0);
  return err;
}

void uejpeg_free_decode_context(uejpeg_decode_context_t *ctx) {
  for (int k = 0; k < 4; ++k) {
    if(ctx->yuva[k]) s_uejpeg_alloc.free(ctx->yuva[k]);
  }
  free_splits(&ctx->spx);
}

uejpeg_decode_context_t uejpeg_decode_threaded_start(const uejpeg_io_callbacks_t *io, void *io_user, int flags) {
  tmEnter(0,0,__FUNCTION__);
  uejpeg_decode_context_t ctx = {0};
  int err = UEJPEG_ERR_CORRUPT_UEJPEG_FILE;

  ctx.flags = flags;

  char magic[6];
  if(io->read(io_user, magic, 6) != 6) {
      goto fail;
  }
  if(memcmp(magic, "OOJPEG", 6)) {
      goto fail;
  }

  int width = 0, height = 0, comp = 0, bit_depth = 0;
  chunk_t c;

  // IHDR chunk
  if (io->read(io_user, &c, 8) != 8) goto fail;
  if(c.type != 'RDHI') goto fail;
  if(io->read(io_user, &ctx.ihdr, sizeof(ctx.ihdr)) != sizeof(ctx.ihdr)) goto fail;
  if(ctx.ihdr.version != UEJPEG_IMAGE_VERSION) goto fail;
  width = ctx.ihdr.width; if(!width || width > (1<<24)) goto fail;
  height = ctx.ihdr.height; if(!height || height > (1<<24)) goto fail;
  comp = ctx.ihdr.comp; if(comp != 1 && comp != 3 && comp != 4) goto fail;
  bit_depth = ctx.ihdr.bit_depth; if(bit_depth != 8) goto fail;
  if(!stbi__mad3sizes_valid(width, height, comp, 0)) goto fail;
  //if(width*height*2+sizeof(uejpeg_lossy_hdr_t) > idat_size) return 0;
  if(ctx.ihdr.num_splits < 1 || ctx.ihdr.num_splits > UEJPEG_MAX_SPLITS) goto fail;
  if(width*height*comp == 0) goto fail;

  // LHDR chunk
  if(io->read(io_user, &c, 8) != 8) goto fail;
  if(c.type != 'RDHL') goto fail;
  if(io->read(io_user, &ctx.lhdr, sizeof(ctx.lhdr)) != sizeof(ctx.lhdr)) goto fail;

  // validate lhdr
  {
    if(ctx.lhdr.app14_color_transform != (char)-1 && ctx.lhdr.app14_color_transform != 0 && ctx.lhdr.app14_color_transform != 1 && ctx.lhdr.app14_color_transform != 2) goto fail;
    int h_max = 1, v_max = 1;
    for(int i=0; i < comp; ++i) {
      if (ctx.lhdr.coef_dims[i][0] > h_max) h_max = ctx.lhdr.coef_dims[i][0];
      if (ctx.lhdr.coef_dims[i][1] > v_max) v_max = ctx.lhdr.coef_dims[i][1];
    }
    for(int i = 0; i < comp; ++i) {
      int hs = h_max / ctx.lhdr.coef_dims[i][0];
      if(ctx.lhdr.coef_dims[i][0] * 8 > ((width+7)/8*8)+8) goto fail; // || ctx.lhdr.coef_dims[i][1] * 8 > ((height+7)/8*8)) goto fail;
      if(ctx.lhdr.coef_dims[i][0] * 8 < (width/8*8/hs)) goto fail;
      if(ctx.lhdr.coef_dims[i][0] * ctx.lhdr.coef_dims[i][1] == 0) goto fail;
    }
    for(int i = comp; i < 4; ++i) {
      if(ctx.lhdr.coef_dims[i][0] != 0 || ctx.lhdr.coef_dims[i][1] != 0) goto fail;
    }
    for(int i=0; i < comp; ++i) {
      int hs = h_max / ctx.lhdr.coef_dims[i][0];
      int vs = v_max / ctx.lhdr.coef_dims[i][1];
      if(hs != 1 && hs != 2) { err = UEJPEG_ERR_UNSUPPORTED; goto fail; }
      if(vs != 1 && vs != 2) { err = UEJPEG_ERR_UNSUPPORTED; goto fail; }
      if(h_max % ctx.lhdr.coef_dims[i][0]) goto fail;
      if(v_max % ctx.lhdr.coef_dims[i][1]) goto fail;
    }
  }

  ctx.spx = make_splits(ctx.ihdr.num_splits, &ctx.lhdr);

  for(int sp = 0; sp < ctx.ihdr.num_splits; ++sp) {
    if(io->read(io_user, &c, 8) != 8) goto fail;
    if(c.type != 'TLPS') goto fail;
    ctx.spx.splits[sp].oodle_buf = (unsigned char*)s_uejpeg_alloc.alloc(c.length);
    ctx.spx.splits[sp].oodle_size = c.length;
    if(ctx.spx.splits[sp].oodle_size != ctx.spx.splits[sp].coefs_size*2 && ctx.ihdr.method == 0) goto fail;
    if(!ctx.spx.splits[sp].oodle_buf) { err = UEJPEG_ERR_OUT_OF_MEMORY; goto fail; }
    if(io->read(io_user, ctx.spx.splits[sp].oodle_buf, c.length) != c.length) goto fail;
  }

  for(int cc = 0; cc < 4; ++cc) {
    int bw = ctx.lhdr.coef_dims[cc][0];
    int bh = ctx.lhdr.coef_dims[cc][1];
    int num_blocks = bw * bh;
    int bstride = bw * 8;
    ctx.yuva_stride[cc] = bstride;
    ctx.yuva_height[cc] = bh * 8;
    ctx.yuva[cc] = (unsigned char *)s_uejpeg_alloc.alloc(num_blocks * 64);
    if(!ctx.yuva[cc]) {
      err = UEJPEG_ERR_OUT_OF_MEMORY;
      goto fail;
    }
  }

  ctx.jobs_to_run = ctx.ihdr.num_splits;

  tmLeave(0);
  return ctx;

fail:
  ctx.error = err;
  uejpeg_free_decode_context(&ctx);
  tmLeave(0);
  return ctx;
}

// These constants come from libjpegturbo.
// they are calculated via for example
//  (1.082392200 * 256.0 + 0.5) == 277
// however!! compilers don't calculate this correctly so you have to just
// use their pre-computed constant numbers directly instead.
#define UEJ_1_082392200  ((long)277)
#define UEJ_1_414213562  ((long)362)
#define UEJ_1_847759065  ((long)473)
#define UEJ_2_613125930  ((long)669)
#define UEJ_1_613125930  ((long)(669 - 256))
    
static inline unsigned char range_limit(int c) {
  c += 128;
  if((unsigned)c > 255) { if(c < 0) c = 0; else c = 255; }
  return (unsigned char)c;
}

#define UEJ__IDCT_1D(s0,s1,s2,s3,s4,s5,s6,s7) \
  short tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7; \
  short tmp10, tmp11, tmp12, tmp13; \
  short z5, z10, z11, z12, z13; \
  tmp10 = ((short)s0 + (short)s4);\
  tmp11 = ((short)s0 - (short)s4);\
  tmp13 = ((short)s2 + (short)s6);\
  tmp12 = ((((short)s2 - (short)s6) * UEJ_1_414213562) >> 8) - tmp13;\
  tmp0 = tmp10 + tmp13;\
  tmp3 = tmp10 - tmp13;\
  tmp1 = tmp11 + tmp12;\
  tmp2 = tmp11 - tmp12;\
  z13 = (short)s5 + (short)s3;\
  z10 = (short)s5 - (short)s3;\
  z11 = (short)s1 + (short)s7;\
  z12 = (short)s1 - (short)s7;\
  tmp7 = z11 + z13;\
  tmp11 = ((z11 - z13) * UEJ_1_414213562) >> 8;\
  z5 = ((z10 + z12) * UEJ_1_847759065) >> 8;\
  tmp10 = ((z12 * UEJ_1_082392200) >> 8) - z5;\
  tmp12 = ((z10 * -UEJ_2_613125930) >> 8) + z5;\
  tmp6 = tmp12 - tmp7;\
  tmp5 = tmp11 - tmp6;\
  tmp4 = tmp10 + tmp5;

void uej__idct_fast_block(unsigned char *out, int out_stride, short *inptr)
{
  int *wsptr;
  int ws[64];

  wsptr = ws;
  for(int i = 0; i < 8; ++i, inptr++, wsptr++) {
    // if all zeroes, shortcut -- this avoids dequantizing 0s and IDCTing
    if (inptr[8] == 0 && inptr[16] == 0 && inptr[24] == 0 && inptr[32] == 0 && inptr[40] == 0 && inptr[48] == 0 && inptr[56] == 0) {
      int dc = inptr[0];
      wsptr[0] = wsptr[8] = wsptr[16] = wsptr[24] = wsptr[32] = wsptr[40] = wsptr[48] = wsptr[56] = dc;
      continue;
    }

    UEJ__IDCT_1D(inptr[0], inptr[8], inptr[16], inptr[24], inptr[32], inptr[40], inptr[48], inptr[56]);

    wsptr[0]  = tmp0 + tmp7;
    wsptr[56] = tmp0 - tmp7;
    wsptr[8]  = tmp1 + tmp6;
    wsptr[48] = tmp1 - tmp6;
    wsptr[16] = tmp2 + tmp5;
    wsptr[40] = tmp2 - tmp5;
    wsptr[32] = tmp3 + tmp4;
    wsptr[24] = tmp3 - tmp4;
  }

  wsptr = ws;
  for (int i = 0; i < 8; i++, wsptr+=8) {
    unsigned char *outptr = out + out_stride*i;
    // if all zeroes, shortcut -- this avoids dequantizing 0s and IDCTing
    if (wsptr[1] == 0 && wsptr[2] == 0 && wsptr[3] == 0 && wsptr[4] == 0 && wsptr[5] == 0 && wsptr[6] == 0 && wsptr[7] == 0) {
      unsigned char dc = range_limit(wsptr[0] >> (2 + 3));
      outptr[0] = outptr[1] = outptr[2] = outptr[3] = outptr[4] = outptr[5] = outptr[6] = outptr[7] = dc;
      continue;
    }

    UEJ__IDCT_1D(wsptr[0], wsptr[1], wsptr[2], wsptr[3], wsptr[4], wsptr[5], wsptr[6], wsptr[7]);

    outptr[0] = range_limit(((tmp0 + tmp7) >> (2 + 3)));
    outptr[7] = range_limit(((tmp0 - tmp7) >> (2 + 3)));
    outptr[1] = range_limit(((tmp1 + tmp6) >> (2 + 3)));
    outptr[6] = range_limit(((tmp1 - tmp6) >> (2 + 3)));
    outptr[2] = range_limit(((tmp2 + tmp5) >> (2 + 3)));
    outptr[5] = range_limit(((tmp2 - tmp5) >> (2 + 3)));
    outptr[4] = range_limit(((tmp3 + tmp4) >> (2 + 3)));
    outptr[3] = range_limit(((tmp3 - tmp4) >> (2 + 3)));
  }
}

#undef UEJ__IDCT_1D

#ifdef UEJ_SSE2
// Note: this matches turbo's SIMD implementation, but turbo's SIMD implementation does not
// match its scalar's implementation. In the second pass it overflows on the calculation of z5 
// when adding z10 and z12.  
void uej__idct_fast_block_simd(unsigned char *out, int out_stride, short data[64])
{
  __m128i tmp0,tmp1,tmp2,tmp3,tmp4,tmp5,tmp6,tmp7;
  __m128i tmp10,tmp11,tmp12,tmp13;
  __m128i z5,z10,z11,z12,z13;
  __m128i ws[8];

#define UEJ__IDCT_1D(s0,s1,s2,s3,s4,s5,s6,s7) \
  tmp10 = _mm_add_epi16(s0, s4);\
  tmp11 = _mm_sub_epi16(s0, s4);\
  tmp13 = _mm_add_epi16(s2, s6);\
  tmp12 = _mm_sub_epi16(_mm_mulhi_epi16(_mm_slli_epi16(_mm_sub_epi16(s2, s6), 2), _mm_set1_epi16(UEJ_1_414213562<<6)), tmp13);\
  tmp0 = _mm_add_epi16(tmp10, tmp13);\
  tmp3 = _mm_sub_epi16(tmp10, tmp13);\
  tmp1 = _mm_add_epi16(tmp11, tmp12);\
  tmp2 = _mm_sub_epi16(tmp11, tmp12);\
  z13 = _mm_add_epi16(s5, s3);\
  z10 = _mm_sub_epi16(s5, s3);\
  z11 = _mm_add_epi16(s1, s7);\
  z12 = _mm_sub_epi16(s1, s7);\
  tmp7 = _mm_add_epi16(z11, z13);\
  tmp11 = _mm_mulhi_epi16(_mm_slli_epi16(_mm_sub_epi16(z11, z13), 2), _mm_set1_epi16(UEJ_1_414213562<<6));\
  z5 = _mm_mulhi_epi16(_mm_slli_epi16(_mm_add_epi16(z10, z12), 2), _mm_set1_epi16(UEJ_1_847759065<<6));\
  tmp10 = _mm_sub_epi16(_mm_mulhi_epi16(_mm_slli_epi16(z12, 2), _mm_set1_epi16(UEJ_1_082392200<<6)), z5);\
  tmp12 = _mm_add_epi16(_mm_sub_epi16(_mm_mulhi_epi16(_mm_slli_epi16(z10, 2), _mm_set1_epi16(-UEJ_1_613125930<<6)), z10), z5);\
  tmp6 = _mm_sub_epi16(tmp12, tmp7);\
  tmp5 = _mm_sub_epi16(tmp11, tmp6);\
  tmp4 = _mm_add_epi16(tmp10, tmp5);

  ws[0] = _mm_load_si128((const __m128i *)(data + 0));
  ws[1] = _mm_load_si128((const __m128i *)(data + 8));
  ws[2] = _mm_load_si128((const __m128i *)(data + 16));
  ws[3] = _mm_load_si128((const __m128i *)(data + 24));
  ws[4] = _mm_load_si128((const __m128i *)(data + 32));
  ws[5] = _mm_load_si128((const __m128i *)(data + 40));
  ws[6] = _mm_load_si128((const __m128i *)(data + 48));
  ws[7] = _mm_load_si128((const __m128i *)(data + 56));

  UEJ__IDCT_1D(ws[0], ws[1], ws[2], ws[3], ws[4], ws[5], ws[6], ws[7]);

  ws[0] = _mm_add_epi16(tmp0, tmp7);
  ws[7] = _mm_sub_epi16(tmp0, tmp7);
  ws[1] = _mm_add_epi16(tmp1, tmp6);
  ws[6] = _mm_sub_epi16(tmp1, tmp6);
  ws[2] = _mm_add_epi16(tmp2, tmp5);
  ws[5] = _mm_sub_epi16(tmp2, tmp5);
  ws[4] = _mm_add_epi16(tmp3, tmp4);
  ws[3] = _mm_sub_epi16(tmp3, tmp4);

  // Now transpose ws
  {
    __m128i tmp;

    // 16-bit interleave step (for transposes)
    #define dct_interleave16(a, b) \
        tmp = a; \
        a = _mm_unpacklo_epi16(a, b); \
        b = _mm_unpackhi_epi16(tmp, b)

    // 16bit 8x8 transpose pass 1
    dct_interleave16(ws[0], ws[4]);
    dct_interleave16(ws[1], ws[5]);
    dct_interleave16(ws[2], ws[6]);
    dct_interleave16(ws[3], ws[7]);

    // transpose pass 2
    dct_interleave16(ws[0], ws[2]);
    dct_interleave16(ws[1], ws[3]);
    dct_interleave16(ws[4], ws[6]);
    dct_interleave16(ws[5], ws[7]);

    // transpose pass 3
    dct_interleave16(ws[0], ws[1]);
    dct_interleave16(ws[2], ws[3]);
    dct_interleave16(ws[4], ws[5]);
    dct_interleave16(ws[6], ws[7]);

    #undef dct_interleave16
  }

  UEJ__IDCT_1D(ws[0], ws[1], ws[2], ws[3], ws[4], ws[5], ws[6], ws[7]);

  ws[0] = _mm_add_epi16(_mm_srai_epi16(_mm_add_epi16(tmp0, tmp7), 5), _mm_set1_epi16(128));
  ws[7] = _mm_add_epi16(_mm_srai_epi16(_mm_sub_epi16(tmp0, tmp7), 5), _mm_set1_epi16(128));
  ws[1] = _mm_add_epi16(_mm_srai_epi16(_mm_add_epi16(tmp1, tmp6), 5), _mm_set1_epi16(128));
  ws[6] = _mm_add_epi16(_mm_srai_epi16(_mm_sub_epi16(tmp1, tmp6), 5), _mm_set1_epi16(128));
  ws[2] = _mm_add_epi16(_mm_srai_epi16(_mm_add_epi16(tmp2, tmp5), 5), _mm_set1_epi16(128));
  ws[5] = _mm_add_epi16(_mm_srai_epi16(_mm_sub_epi16(tmp2, tmp5), 5), _mm_set1_epi16(128));
  ws[4] = _mm_add_epi16(_mm_srai_epi16(_mm_add_epi16(tmp3, tmp4), 5), _mm_set1_epi16(128));
  ws[3] = _mm_add_epi16(_mm_srai_epi16(_mm_sub_epi16(tmp3, tmp4), 5), _mm_set1_epi16(128));

  {
    __m128i tmp;
    // 8-bit interleave step (for transposes)
    #define dct_interleave8(a, b) \
        tmp = a; \
        a = _mm_unpacklo_epi8(a, b); \
        b = _mm_unpackhi_epi8(tmp, b)

    // pack
    __m128i p0 = _mm_packus_epi16(ws[0], ws[1]); // a0a1a2a3...a7b0b1b2b3...b7
    __m128i p1 = _mm_packus_epi16(ws[2], ws[3]);
    __m128i p2 = _mm_packus_epi16(ws[4], ws[5]);
    __m128i p3 = _mm_packus_epi16(ws[6], ws[7]);

    // 8bit 8x8 transpose pass 1
    dct_interleave8(p0, p2); // a0e0a1e1...
    dct_interleave8(p1, p3); // c0g0c1g1...

    // transpose pass 2
    dct_interleave8(p0, p1); // a0c0e0g0...
    dct_interleave8(p2, p3); // b0d0f0h0...

    // transpose pass 3
    dct_interleave8(p0, p2); // a0b0c0d0...
    dct_interleave8(p1, p3); // a4b4c4d4...

    _mm_storel_epi64((__m128i *) out, p0); out += out_stride;
    _mm_storel_epi64((__m128i *) out, _mm_shuffle_epi32(p0, 0x4e)); out += out_stride;
    _mm_storel_epi64((__m128i *) out, p2); out += out_stride;
    _mm_storel_epi64((__m128i *) out, _mm_shuffle_epi32(p2, 0x4e)); out += out_stride;
    _mm_storel_epi64((__m128i *) out, p1); out += out_stride;
    _mm_storel_epi64((__m128i *) out, _mm_shuffle_epi32(p1, 0x4e)); out += out_stride;
    _mm_storel_epi64((__m128i *) out, p3); out += out_stride;
    _mm_storel_epi64((__m128i *) out, _mm_shuffle_epi32(p3, 0x4e));

    #undef dct_interleave8
  }
#undef UEJ__IDCT_1D
}
#endif

int uejpeg_decode_thread_run(uejpeg_decode_context_t *ctx, int job_idx) {
  if(ctx->error) {
    return ctx->error;
  }
  tmEnter(0,0,__FUNCTION__);
  stbi__jpeg z;
  stbi__setup_jpeg(&z);

  int sp = job_idx;

  // No compression?
  if(ctx->ihdr.method == 0) {
    memcpy(ctx->spx.splits[sp].split_xcoefs, ctx->spx.splits[sp].oodle_buf, ctx->spx.splits[sp].coefs_size*2);
  } else {
    if(ctx->spx.splits[sp].oodle_size && !s_uejpeg_compression.decompress(ctx->spx.splits[sp].oodle_buf, ctx->spx.splits[sp].oodle_size, 
                                        ctx->spx.splits[sp].split_xcoefs, ctx->spx.splits[sp].coefs_size*2)) {
      ctx->error = UEJPEG_ERR_CORRUPT_UEJPEG_FILE;
      tmLeave(0);
      return ctx->error;
    }
  }

  // put hi/lo bytes back together into shorts
  combine_hi_lo((unsigned char*)ctx->spx.splits[sp].split_xcoefs, 
    (unsigned char*)ctx->spx.splits[sp].split_xcoefs + ctx->spx.splits[sp].coefs_size,
    (unsigned short*)ctx->spx.splits[sp].xcoefs,
    ctx->spx.splits[sp].coefs_size);

  unsigned short dequant[4][64];
  if(ctx->flags & UEJPEG_FLAG_FASTDCT) {
    // Note: This table comes from libjpegturbo
    static const short aanscales[64] = {
      16384, 22725, 21407, 19266, 16384, 12873,  8867,  4520,
      22725, 31521, 29692, 26722, 22725, 17855, 12299,  6270,
      21407, 29692, 27969, 25172, 21407, 16819, 11585,  5906,
      19266, 26722, 25172, 22654, 19266, 15137, 10426,  5315,
      16384, 22725, 21407, 19266, 16384, 12873,  8867,  4520,
      12873, 17855, 16819, 15137, 12873, 10114,  6967,  3552,
       8867, 12299, 11585, 10426,  8867,  6967,  4799,  2446,
       4520,  6270,  5906,  5315,  4520,  3552,  2446,  1247
    };

    for(int c = 0; c < 4; ++c) {
      for(int i = 0; i < 64; ++i) {
          dequant[c][i] = ((ctx->lhdr.dequant[c][s_uejpeg_zigzag[i]] * aanscales[s_uejpeg_zigzag[i]]) + (1<<11)) >> 12;
      }
    }
  }

  // now decode
  {
    tmEnter(0,0,"gather & idcts");
    short *D = ctx->spx.splits[sp].xcoefs;
    for(int cc = 0; cc < 4; ++cc) {
      int bw = ctx->spx.splits[sp].width[cc];
      int bh = ctx->spx.splits[sp].height[cc];
      int num_blocks = bw * bh;
      int bstride = bw * 8;
      for(int y = 0, yy = ctx->spx.splits[sp].y_start[cc]; y < bh; ++y, ++yy) {
        for(int x = 0; x < bw; ++x) {
          short C[64];
          if(ctx->flags & UEJPEG_FLAG_FASTDCT) {
            for(int e = 0; e < 64; ++e) {
              int d = e*num_blocks + y*bw+x;
              C[s_uejpeg_zigzag[e]] = (D[d] - 0x80) * dequant[cc][e];
            }
#ifdef UEJ_SSE2
            uej__idct_fast_block_simd(ctx->yuva[cc] + yy*8*bstride + x*8, bstride, C);
#else
            uej__idct_fast_block(ctx->yuva[cc] + yy*8*bstride + x*8, bstride, C);
#endif
          } else {
            for(int e = 0; e < 64; ++e) {
              int d = e*num_blocks + y*bw+x;
              C[s_uejpeg_zigzag[e]] = (D[d] - 0x80) * ctx->lhdr.dequant[cc][s_uejpeg_zigzag[e]];
            }
            z.idct_block_kernel(ctx->yuva[cc] + yy*8*bstride + x*8, bstride, C);
          }
        }
      }
      D += num_blocks * 64;
    }
    tmLeave(0);
  }
  tmLeave(0);
  return 0;
}

unsigned char *uejpeg_decode_threaded_finish(uejpeg_decode_context_t *ctx, int *out_width, int *out_height, int *out_comp) {
  unsigned char *out_image = 0;
  unsigned char *linebufs[4] = {0};
  int out_n = 4;
  int width = ctx->ihdr.width;
  int height = ctx->ihdr.height;
  int bit_depth = ctx->ihdr.bit_depth;

  *out_width = 0;
  *out_height = 0;
  *out_comp = 0;

  if(ctx->error) {
    return 0;
  }
  tmEnter(0,0,__FUNCTION__);

  out_image = (unsigned char*)s_uejpeg_alloc.alloc(((long long)width*height*out_n*bit_depth + 7) / 8);
  if(!out_image) goto fail;

  stbi__jpeg z;
  stbi__setup_jpeg(&z);

  int h_max = 1, v_max = 1;
  for(int i=0; i < 4; ++i) {
    if (ctx->lhdr.coef_dims[i][0] > h_max) h_max = ctx->lhdr.coef_dims[i][0];
    if (ctx->lhdr.coef_dims[i][1] > v_max) v_max = ctx->lhdr.coef_dims[i][1];
  }

  int rgb = 0;
  for (int i = 0; i < ctx->ihdr.comp; ++i) {
    if (ctx->ihdr.comp == 3 && ctx->lhdr.comp_id[i] == "RGB"[i]) {
      ++rgb;
    }
  }
  int is_rgb = ctx->ihdr.comp == 3 && (rgb == 3 || (ctx->lhdr.app14_color_transform == 0 && !ctx->lhdr.jfif));

  // resample and color-convert
  {
    tmEnter(0,0,"resample & color-convert");
    unsigned char *coutput[4] = {0};
    stbi__resample res_comp[4] = {{0}};

    int vs_max = 0;
    int hs_max = 0;

    for (int k = 0; k < 4; ++k) {
      if (!ctx->lhdr.coef_dims[k][0] || !ctx->lhdr.coef_dims[k][1]) {
        continue;
      }
      stbi__resample *r = &res_comp[k];

      // allocate line buffer big enough for upsampling off the edges
      // with upsample factor of 4
      linebufs[k] = (unsigned char *)s_uejpeg_alloc.alloc(ctx->ihdr.width + 3);

      r->hs = h_max / ctx->lhdr.coef_dims[k][0];
      r->vs = v_max / ctx->lhdr.coef_dims[k][1];
      r->ystep = r->vs >> 1;
      r->w_lores = (ctx->ihdr.width + r->hs - 1) / r->hs;
      r->ypos = 0;
      r->line0 = r->line1 = ctx->yuva[k];

      vs_max = vs_max > r->vs ? vs_max : r->vs;
      hs_max = hs_max > r->hs ? hs_max : r->hs;

      if (r->hs == 1 && r->vs == 1)       r->resample = resample_row_1;
      else if (r->hs == 1 && r->vs == 2)  r->resample = stbi__resample_row_v_2;
      else if (r->hs == 2 && r->vs == 1)  r->resample = stbi__resample_row_h_2;
      else if (r->hs == 2 && r->vs == 2)  r->resample = z.resample_row_hv_2_kernel;
      else                                r->resample = stbi__resample_row_generic;
    }

    // now go ahead and resample
    for (unsigned j = 0; j < ctx->ihdr.height; ++j) {
      unsigned char *out = out_image + out_n * ctx->ihdr.width * j;
      // Resample lines...
      for (int k = 0; k < 4; ++k) {
        if (!ctx->lhdr.coef_dims[k][0] || !ctx->lhdr.coef_dims[k][1]) {
          continue;
        }
        stbi__resample *r = &res_comp[k];
        int y_bot = r->ystep >= (r->vs >> 1);
        coutput[k] = r->resample(linebufs[k], 
                                y_bot ? r->line1 : r->line0, 
                                y_bot ? r->line0 : r->line1, 
                                r->w_lores, r->hs);
        if (++r->ystep >= r->vs) {
          r->ystep = 0;
          r->line0 = r->line1;
          int yy = (ctx->ihdr.height + r->vs-1) / r->vs;
          ++r->ypos;
          if (r->ypos < yy && r->ypos < ctx->yuva_height[k]) {
            r->line1 += ctx->yuva_stride[k];
          }
        }
      }
      if (out_n >= 3) {
        if (ctx->ihdr.comp == 3) {
          if (is_rgb) {
            for (int i = 0; i < width; ++i) {
              out[0] = coutput[0][i];
              out[1] = coutput[1][i];
              out[2] = coutput[2][i];
              out[3] = 255;
              out += out_n;
            }
          } else {
            z.YCbCr_to_RGB_kernel(out, coutput[0], coutput[1], coutput[2], width, out_n);
          }
        } else if (ctx->ihdr.comp == 4) {
          if (ctx->lhdr.app14_color_transform == 0) { // CMYK
            for (int i = 0; i < width; ++i) {
              unsigned char m = coutput[3][i];
              out[0] = uejpeg__blinn_8x8(coutput[0][i], m);
              out[1] = uejpeg__blinn_8x8(coutput[1][i], m);
              out[2] = uejpeg__blinn_8x8(coutput[2][i], m);
              out[3] = 255;
              out += out_n;
            }
          } else if (ctx->lhdr.app14_color_transform == 2) { // YCCK
            z.YCbCr_to_RGB_kernel(out, coutput[0], coutput[1], coutput[2], width, out_n);
            for (int i = 0; i < width; ++i) {
              unsigned char m = coutput[3][i];
              out[0] = uejpeg__blinn_8x8(255 - out[0], m);
              out[1] = uejpeg__blinn_8x8(255 - out[1], m);
              out[2] = uejpeg__blinn_8x8(255 - out[2], m);
              out[3] = 255;
              out += out_n;
            }
          } else { // YCbCr + alpha
            z.YCbCr_to_RGB_kernel(out, coutput[0], coutput[1], coutput[2], width, out_n);
            if(out_n == 4) {
              for (int i = 0; i < width; ++i) {
                out[3] = coutput[3][i];
                out += out_n;
              }
            }
          }
        } else {
          for (int i = 0; i < width; ++i) {
            out[0] = out[1] = out[2] = coutput[0][i];
            out[3] = 255; // not used if out_n==3
            out += out_n;
          }
        }
      } else {
        if (is_rgb) {
          if (out_n == 1) {
            for (int i = 0; i < width; ++i) {
              *out++ = uejpeg__compute_y(coutput[0][i], coutput[1][i], coutput[2][i]);
            }
          } else {
            for (int i = 0; i < width; ++i, out += 2) {
              out[0] = uejpeg__compute_y(coutput[0][i], coutput[1][i], coutput[2][i]);
              out[1] = 255;
            }
          }
        } else if (ctx->ihdr.comp == 4 && ctx->lhdr.app14_color_transform == 0) {
          for (int i = 0; i < width; ++i) {
            unsigned char m = coutput[3][i];
            unsigned char r = uejpeg__blinn_8x8(coutput[0][i], m);
            unsigned char g = uejpeg__blinn_8x8(coutput[1][i], m);
            unsigned char b = uejpeg__blinn_8x8(coutput[2][i], m);
            out[0] = uejpeg__compute_y(r, g, b);
            out[1] = 255;
            out += out_n;
          }
        } else if (ctx->ihdr.comp == 4 && ctx->lhdr.app14_color_transform == 2) {
          for (int i = 0; i < width; ++i) {
            out[0] = uejpeg__blinn_8x8(255 - coutput[0][i], coutput[3][i]);
            out[1] = 255;
            out += out_n;
          }
        } else {
          if (out_n == 1) {
            for (int i = 0; i < width; ++i) {
              out[i] = coutput[0][i];
            }
          } else {
            for (int i = 0; i < width; ++i) {
              *out++ = coutput[0][i], *out++ = 255;
            }
          }
        }
      }
    }
    tmLeave(0);
  }

  uejpeg_free_decode_context(ctx);
  for (int k = 0; k < 4; ++k) {
    if(linebufs[k]) s_uejpeg_alloc.free(linebufs[k]);
  }

  *out_width = ctx->ihdr.width;
  *out_height = ctx->ihdr.height;
  *out_comp = out_n;
  tmLeave(0);
  return out_image;

fail:
  if(out_image) s_uejpeg_alloc.free(out_image);
  uejpeg_free_decode_context(ctx);
  for (int k = 0; k < 4; ++k) {
    if(linebufs[k]) s_uejpeg_alloc.free(linebufs[k]);
  }
  tmLeave(0);
  return 0;
}

unsigned char *uejpeg_decode_mem(const unsigned char *data, int size, int *width, int *height, int *channels, int flags) {
  uejpeg_io_buffer_t user;
  user.base = user.ptr = (char*)data;
  user.size = size;
  return uejpeg_decode(&s_uejpeg_buffer_fns, &user, width, height, channels, flags);
}

int uejpeg_encode_jpeg_mem(const unsigned char *data, int size, unsigned char **out_data, int *out_size, int flags) {
  stbi__context s;
  stbi__start_mem(&s, data, size);

  *out_data = 0;
  *out_size = 0;

  uejpeg_jpeg_info_t jpeg_info;
  if (!uejpeg_read_jpeg_info(&s, &jpeg_info)) {
    //fprintf(stderr, "Error: Not a JPEG file '%s'\n", i_filename);
    return UEJPEG_ERR_NOT_A_JPEG;
  }

  uejpeg_io_buffer_t out_user = {0};
  uejpeg_encode_context_t ctx = uejpeg_encode_jpeg_threaded_start(&s_uejpeg_buffer_fns, &out_user, &jpeg_info, flags);
  for(int i = 0; i < ctx.jobs_to_run; ++i) {
    uejpeg_encode_jpeg_thread_run(&ctx, i);
  }
  uejpeg_encode_jpeg_threaded_finish(&ctx);
  if (ctx.error) return ctx.error;
  *out_data = (unsigned char*)out_user.base;
  *out_size = (int)out_user.size;
  return UEJPEG_ERR_NONE;
}

int uejpeg_decode_mem_to_jpeg(const unsigned char *data, int size, unsigned char **out_data, int *out_size, int flags) {
  uejpeg_io_buffer_t in_user;
  uejpeg_io_buffer_t out_user = {0};

  in_user.base = in_user.ptr = (char*)data;
  in_user.size = size;

  int err = uejpeg_decode_to_jpeg(&s_uejpeg_buffer_fns, &in_user, &s_uejpeg_buffer_fns, &out_user, flags);

  *out_data = (unsigned char*)out_user.base;
  *out_size = (int)out_user.size;

  return err;
}

void uejpeg_set_alloc(const uejpeg_alloc_t *alloc) {
  s_uejpeg_alloc = *alloc;
}

void uejpeg_set_compression(const uejpeg_compression_t *compression) {
  s_uejpeg_compression = *compression;
}

static void uejpeg_fDCT(float *d0, float *d1, float *d2, float *d3, float *d4, float *d5, float *d6, float *d7) {
  float tmp0 = *d0 + *d7;
  float tmp7 = *d0 - *d7;
  float tmp1 = *d1 + *d6;
  float tmp6 = *d1 - *d6;
  float tmp2 = *d2 + *d5;
  float tmp5 = *d2 - *d5;
  float tmp3 = *d3 + *d4;
  float tmp4 = *d3 - *d4;

  // Even part
  float tmp10 = tmp0 + tmp3;  // phase 2
  float tmp13 = tmp0 - tmp3;
  float tmp11 = tmp1 + tmp2;
  float tmp12 = tmp1 - tmp2;

  *d0 = tmp10 + tmp11;  // phase 3
  *d4 = tmp10 - tmp11;

  float z1 = (tmp12 + tmp13) * 0.707106781f;  // c4
  *d2 = tmp13 + z1;                            // phase 5
  *d6 = tmp13 - z1;

  // Odd part
  tmp10 = tmp4 + tmp5;  // phase 2
  tmp11 = tmp5 + tmp6;
  tmp12 = tmp6 + tmp7;

  // The rotator is modified from fig 4-8 to avoid extra negations.
  float z5 = (tmp10 - tmp12) * 0.382683433f;  // c6
  float z2 = tmp10 * 0.541196100f + z5;       // c2-c6
  float z4 = tmp12 * 1.306562965f + z5;       // c2+c6
  float z3 = tmp11 * 0.707106781f;            // c4

  float z11 = tmp7 + z3;  // phase 5
  float z13 = tmp7 - z3;

  *d5 = z13 + z2;  // phase 6
  *d3 = z13 - z2;
  *d1 = z11 + z4;
  *d7 = z11 - z4;
}

static void uejpeg_processDU(float *CDU, int du_stride, float *fdtbl, int DU[64]) {
  // DCT rows
	for(int i=0; i<du_stride*8; i+=du_stride) {
		uejpeg_fDCT(CDU+i, CDU+i+1, CDU+i+2, CDU+i+3, CDU+i+4, CDU+i+5, CDU+i+6, CDU+i+7);
	}
	// DCT columns
	for(int i=0; i<8; ++i) {
		uejpeg_fDCT(CDU+i, CDU+i+du_stride, CDU+i+du_stride*2, CDU+i+du_stride*3, CDU+i+du_stride*4, CDU+i+du_stride*5, CDU+i+du_stride*6, CDU+i+du_stride*7);
	}
	// Quantize/descale/zigzag the coefficients
	for(int y = 0, j=0; y < 8; ++y) {
		for(int x = 0; x < 8; ++x,++j) {
			int i = y*du_stride+x;
			float v = CDU[i]*fdtbl[j];
			DU[s_uejpeg_unzigzag[j]] = (int)(v < 0 ? ceilf(v - 0.5f) : floorf(v + 0.5f));
		}
	}
}

void uejpeg_free_encode_image_context(uejpeg_encode_image_context_t *ctx) {
  free_splits(&ctx->spx);
}

uejpeg_encode_image_context_t uejpeg_encode_image_threaded_start(const uejpeg_io_callbacks_t *io, void *io_user, int width, int height, int comp, const unsigned char *in_data, int quality, int flags) {
	//static const int YQT[] = {16,11,10,16,24,40,51,61,12,12,14,19,26,58,60,55,14,13,16,24,40,57,69,56,14,17,22,29,51,87,80,62,18,22,37,56,68,109,103,77,24,35,55,64,81,104,113,92,49,64,78,87,103,121,120,101,72,92,95,98,112,100,103,99};
	//static const int UVQT[] = {17,18,24,47,99,99,99,99,18,21,26,66,99,99,99,99,24,26,56,99,99,99,99,99,47,66,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99};
  static const int YQT[] = {16,16,16,18,25,37,56,85,16,17,20,27,34,40,53,75,16,20,24,31,43,62,91,135,18,27,31,40,53,74,106,156,25,34,43,53,69,94,131,189,37,40,62,74,94,124,169,238,56,53,91,106,131,169,226,311,85,75,135,156,189,238,311,418};
  static const int UVQT[] = {16,16,16,18,25,37,56,85,16,17,20,27,34,40,53,75,16,20,24,31,43,62,91,135,18,27,31,40,53,74,106,156,25,34,43,53,69,94,131,189,37,40,62,74,94,124,169,238,56,53,91,106,131,169,226,311,85,75,135,156,189,238,311,418};
	static const float aasf[] = { 1.0f * 2.828427125f, 1.387039845f * 2.828427125f, 1.306562965f * 2.828427125f, 1.175875602f * 2.828427125f, 1.0f * 2.828427125f, 0.785694958f * 2.828427125f, 0.541196100f * 2.828427125f, 0.275899379f * 2.828427125f };
  uejpeg_encode_image_context_t ctx = {0};

  tmEnter(0,0,__FUNCTION__);

  ctx.io = io;
  ctx.io_user = io_user;
  ctx.in_data = in_data;
  ctx.flags = flags;
  ctx.width = width;
  ctx.height = height;
  ctx.comp = comp;

	quality = quality ? quality : 90;
	//int subsample = quality <= 90 ? 1 : 0;
	quality = quality < 1 ? 1 : quality > 100 ? 100 : quality;
	quality = quality < 50 ? 5000 / quality : 200 - quality * 2;

	unsigned short YTable[64], UVTable[64];
	for(int i = 0; i < 64; ++i) {
		int yti = (YQT[i]*quality+50)/100;
		YTable[i] = (short)(yti < 1 ? 1 : yti > 0xFFFF ? 0xFFFF : yti);
		int uvti  = (UVQT[i]*quality+50)/100;
		UVTable[i] = (short)(uvti < 1 ? 1 : uvti > 0xFFFF ? 0xFFFF : uvti);
	}

	for(int row = 0, k = 0; row < 8; ++row) {
		for(int col = 0; col < 8; ++col, ++k) {
			ctx.fdtbl_Y[k]  = 1 / (YTable [k] * aasf[row] * aasf[col]);
			ctx.fdtbl_UV[k] = 1 / (UVTable[k] * aasf[row] * aasf[col]);
		}
	}

  ctx.lhdr.jfif = 0;
  ctx.lhdr.app14_color_transform = 1;
  for(int i = 0; i < 64; ++i) {
    ctx.lhdr.dequant[0][i] = YTable[i];
    ctx.lhdr.dequant[1][i] = UVTable[i];
    ctx.lhdr.dequant[2][i] = UVTable[i];
    ctx.lhdr.dequant[3][i] = YTable[i];
  }
  ctx.lhdr.comp_id[0] = 0;
  ctx.lhdr.comp_id[1] = 1;
  ctx.lhdr.comp_id[2] = 2;
  ctx.lhdr.comp_id[3] = 3;
  for(int i = 0; i < comp; ++i) {
    ctx.lhdr.coef_dims[i][0] = (short)((width+7)/8);
    ctx.lhdr.coef_dims[i][1] = (short)((height+7)/8);
  }

  ctx.num_splits = calc_num_splits(ctx.height);
  ctx.spx = make_splits(ctx.num_splits, &ctx.lhdr);
  if(ctx.spx.error) { ctx.error = ctx.spx.error; goto fail; }

  ctx.jobs_to_run = ctx.num_splits;

  tmLeave(0);
  return ctx;
fail:
  uejpeg_free_encode_image_context(&ctx);
  tmLeave(0);
  return ctx;
}

int uejpeg_encode_image_thread_run(uejpeg_encode_image_context_t *ctx, int job_idx) {
  if(ctx->error) {
    return ctx->error;
  }
  tmEnter(0,0,__FUNCTION__);
  int sp = job_idx;
  int width = ctx->width;
  int height = ctx->height;
  int comp = ctx->comp;
  const unsigned char *in_data = ctx->in_data;

  int bw = ctx->spx.splits[sp].width[0];
  int bh = ctx->spx.splits[sp].height[0];
  int num_blocks = bw*bh;
  short *outY = (short*)ctx->spx.splits[sp].xcoefs;
  short *outU = (short*)ctx->spx.splits[sp].xcoefs + num_blocks*(64);
  short *outV = (short*)ctx->spx.splits[sp].xcoefs + num_blocks*(64+64);
  short *outA = (short*)ctx->spx.splits[sp].xcoefs + num_blocks*(64+64+64);

  int y_start = ctx->spx.splits[sp].y_start[0];
  int y_end = ctx->spx.splits[sp].y_end[0];
  {
    int du_stride = num_blocks;
    int du_idx = 0;
    for(int y = y_start*8; y < y_end*8; y+=8) {
      for(int x = 0; x < width; x+=8) {
        float YDU[64], UDU[64], VDU[64], ADU[64];
        for(int row = y, pos = 0; row < y+8; ++row) {
          for(int col = x; col < x+8; ++col, ++pos) {
            int p = row*width*comp + col*comp;
            if(row >= height) {
              p -= width*comp*(row+1 - height);
            }
            if(col >= width) {
              p -= comp*(col+1 - width);
            }

            float r = in_data[p+0], g = in_data[p+1], b = in_data[p+2], a = comp == 4 ? in_data[p+3] : 255.f;
            YDU[pos] = +0.29900f*r+0.58700f*g+0.11400f*b-128;
            UDU[pos] = -0.16874f*r-0.33126f*g+0.50000f*b;
            VDU[pos] = +0.50000f*r-0.41869f*g-0.08131f*b;
            ADU[pos] = a-128;
          }
        }

        int DUY[64], DUU[64], DUV[64], DUA[64];
        uejpeg_processDU(YDU, 8, ctx->fdtbl_Y, DUY);
        uejpeg_processDU(UDU, 8, ctx->fdtbl_UV, DUU);
        uejpeg_processDU(VDU, 8, ctx->fdtbl_UV, DUV);
        uejpeg_processDU(ADU, 8, ctx->fdtbl_Y, DUA);

        for(int i = 0; i < 64; ++i) {
          outY[i*du_stride + du_idx] = (short)(DUY[i] + 0x80);
          outU[i*du_stride + du_idx] = (short)(DUU[i] + 0x80);
          outV[i*du_stride + du_idx] = (short)(DUV[i] + 0x80);
          if(comp == 4) outA[i*du_stride + du_idx] = (short)(DUA[i] + 0x80);
        }

        ++du_idx;
      }
    }
  }
  
  // split bytes of int16 into their own sections
  {
    short *dct_data = ctx->spx.splits[sp].xcoefs;
    char *dct_a = ctx->spx.splits[sp].split_xcoefs;
    char *dct_b = ctx->spx.splits[sp].split_xcoefs + ctx->spx.splits[sp].coefs_size;
    for(int i = 0; i < ctx->spx.splits[sp].coefs_size; ++i) {
      dct_a[i] = dct_data[i] & 0xFF;
      dct_b[i] = dct_data[i] >> 8;
    }
  }

  if(ctx->flags & UEJPEG_FLAG_NO_COMPRESSION) {
    ctx->spx.splits[sp].oodle_buf = (unsigned char *)s_uejpeg_alloc.alloc(ctx->spx.splits[sp].coefs_size*2);
    ctx->spx.splits[sp].oodle_size = (int)ctx->spx.splits[sp].coefs_size*2;
    memcpy(ctx->spx.splits[sp].oodle_buf, ctx->spx.splits[sp].split_xcoefs, ctx->spx.splits[sp].coefs_size*2);
  } else {
    uejpeg_buffer_t oodle = s_uejpeg_compression.compress(ctx->spx.splits[sp].split_xcoefs, ctx->spx.splits[sp].coefs_size*2);
    ctx->spx.splits[sp].oodle_buf = (unsigned char *)oodle.data;
    ctx->spx.splits[sp].oodle_size = (int)oodle.size;
  }
  tmLeave(0);
  return 0;
}

int uejpeg_encode_image_threaded_finish(uejpeg_encode_image_context_t *ctx) {
  if(ctx->error) {
    return ctx->error;
  }

  tmEnter(0,0,__FUNCTION__);

  // Write uejpeg file header
  ctx->io->write(ctx->io_user, "OOJPEG", 6);

  uejpeg_ihdr_t uejpeg_ihdr = {0};
  uejpeg_ihdr.version = UEJPEG_IMAGE_VERSION;
  uejpeg_ihdr.width = ctx->width;
  uejpeg_ihdr.height = ctx->height;
  uejpeg_ihdr.bit_depth = 8;
  uejpeg_ihdr.comp = (unsigned char)ctx->comp; // RGB(A?)
  if(ctx->flags & UEJPEG_FLAG_NO_COMPRESSION) {
    uejpeg_ihdr.method = 0; // No Compression
  } else {
    uejpeg_ihdr.method = 0x0D; // Oodle LZ
  }
  uejpeg_ihdr.num_splits = (unsigned char)ctx->num_splits;

  // Write IHDR
  chunk_t ihdr_chunk = {sizeof uejpeg_ihdr, 'RDHI'};
  if(ctx->io->write(ctx->io_user, &ihdr_chunk, 8) != 8) { ctx->error = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  if(ctx->io->write(ctx->io_user, &uejpeg_ihdr, sizeof uejpeg_ihdr) != sizeof uejpeg_ihdr) { ctx->error = UEJPEG_ERR_WRITE_FAILED; goto fail; }

  // Write LHDR
  chunk_t lhdr_chunk = {sizeof ctx->lhdr, 'RDHL'};
  if(ctx->io->write(ctx->io_user, &lhdr_chunk, 8) != 8) { ctx->error = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  if(ctx->io->write(ctx->io_user, &ctx->lhdr, sizeof ctx->lhdr) != sizeof ctx->lhdr) { ctx->error = UEJPEG_ERR_WRITE_FAILED; goto fail; }

  // Write SPLT chunks
  for(int sp = 0; sp < ctx->num_splits; ++sp) {
    if(ctx->io->write(ctx->io_user, &ctx->spx.splits[sp].oodle_size, 4) != 4) { ctx->error = UEJPEG_ERR_WRITE_FAILED; goto fail; }
    if(ctx->io->write(ctx->io_user, "SPLT", 4) != 4) { ctx->error = UEJPEG_ERR_WRITE_FAILED; goto fail; }
    if(ctx->io->write(ctx->io_user, ctx->spx.splits[sp].oodle_buf, ctx->spx.splits[sp].oodle_size) != ctx->spx.splits[sp].oodle_size) { ctx->error = UEJPEG_ERR_WRITE_FAILED; goto fail; }
  }

fail:
  uejpeg_free_encode_image_context(ctx);
  tmLeave(0);
  return ctx->error;
}

int uejpeg_encode_to_mem(unsigned char **out_data, int *out_size, int width, int height, int channels, const unsigned char *data, int quality, int flags) {
  uejpeg_io_buffer_t out_user = {0};

  uejpeg_encode_image_context_t ctx = uejpeg_encode_image_threaded_start(&s_uejpeg_buffer_fns, &out_user, width, height, channels, data, quality, flags);
  for(int i = 0; i < ctx.jobs_to_run; ++i) {
    uejpeg_encode_image_thread_run(&ctx, i);
  }
  int err = uejpeg_encode_image_threaded_finish(&ctx);

  *out_data = (unsigned char*)out_user.base;
  *out_size = (int)out_user.size;

  return err;
}

uejpeg_encode_context_t uejpeg_encode_jpeg_mem_threaded_start(const unsigned char *data, int size, int flags) {
  uejpeg_encode_context_t ctx = {0};
  stbi__context s;
  stbi__start_mem(&s, data, size);

  uejpeg_jpeg_info_t jpeg_info;
  if (!uejpeg_read_jpeg_info(&s, &jpeg_info)) {
    ctx.error = UEJPEG_ERR_NOT_A_JPEG;
    return ctx;
  }

  uejpeg_io_buffer_t *out_user = (uejpeg_io_buffer_t*)s_uejpeg_alloc.alloc(sizeof(uejpeg_io_buffer_t));
  if(!out_user) {
    ctx.error = UEJPEG_ERR_OUT_OF_MEMORY;
    return ctx;
  }
  memset(out_user, 0, sizeof(*out_user));

  ctx = uejpeg_encode_jpeg_threaded_start(&s_uejpeg_buffer_fns, out_user, &jpeg_info, flags);
  for(int i = 0; i < 4; ++i) {
    if(jpeg_info.coefs[i]) s_uejpeg_alloc.free(jpeg_info.coefs[i]);
  }
  return ctx;
}

int uejpeg_encode_jpeg_mem_threaded_finish(uejpeg_encode_context_t *ctx, unsigned char **out_data, int *out_size) {
  uejpeg_encode_jpeg_threaded_finish(ctx);
  *out_data = (unsigned char*)((uejpeg_io_buffer_t*)ctx->io_user)->base;
  *out_size = (int)((uejpeg_io_buffer_t*)ctx->io_user)->size;
  s_uejpeg_alloc.free(ctx->io_user);
  return ctx->error;
}

uejpeg_decode_context_t uejpeg_decode_mem_threaded_start(const unsigned char *data, int size, int flags) {
  uejpeg_decode_context_t ctx = {0};

  uejpeg_io_buffer_t user = {0};
  user.base = user.ptr = (char*)data;
  user.size = size;
  ctx = uejpeg_decode_threaded_start(&s_uejpeg_buffer_fns, &user, flags);
  return ctx;
}

unsigned char *uejpeg_decode(const uejpeg_io_callbacks_t *io, void *io_user, int *out_width, int *out_height, int *out_comp, int flags) {
  *out_width = 0;
  *out_height = 0;
  *out_comp = 0;
  uejpeg_decode_context_t ctx = uejpeg_decode_threaded_start(io, io_user, flags);
  if(ctx.error) {
    return 0;
  }
  for(int i = 0; i < ctx.jobs_to_run; ++i) {
    uejpeg_decode_thread_run(&ctx, i);
    if(ctx.error) {
      return 0;
    }
  }
  return uejpeg_decode_threaded_finish(&ctx, out_width, out_height, out_comp);
}

uejpeg_encode_image_context_t uejpeg_encode_image_mem_threaded_start(int width, int height, int comp, const unsigned char *in_data, int quality, int flags) {
  uejpeg_encode_image_context_t ctx = {0};

  uejpeg_io_buffer_t *out_user = (uejpeg_io_buffer_t*)s_uejpeg_alloc.alloc(sizeof(uejpeg_io_buffer_t));
  if(!out_user) {
    ctx.error = UEJPEG_ERR_OUT_OF_MEMORY;
    return ctx;
  }
  memset(out_user, 0, sizeof(*out_user));

  ctx = uejpeg_encode_image_threaded_start(&s_uejpeg_buffer_fns, out_user, width, height, comp, in_data, quality, flags);
  return ctx;
}

int uejpeg_encode_image_mem_threaded_finish(uejpeg_encode_image_context_t *ctx, unsigned char **out_data, int *out_size) {
  uejpeg_encode_image_threaded_finish(ctx);
  uejpeg_io_buffer_t *out_user = (uejpeg_io_buffer_t*)ctx->io_user;
  *out_data = (unsigned char*)out_user->base;
  *out_size = (int)out_user->size;
  s_uejpeg_alloc.free(ctx->io_user);
  return ctx->error;
}
